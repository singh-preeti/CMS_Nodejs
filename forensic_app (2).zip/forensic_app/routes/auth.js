const express = require("express");
const bcrypt = require("bcrypt");
const { pool, recordAudit } = require("../database/database");

const router = express.Router();

router.get("/login", (req, res) => {
  res.render("login", { error: null });
});

router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.render("login", { error: "Username and password are required." });
  }

  const { rows } = await pool.query(
    "SELECT * FROM users WHERE username = $1",
    [username.trim()]
  );
  const user = rows[0];

  if (!user) {
    return res.render("login", { error: "Invalid username " });
  }

  const validPassword = await bcrypt.compare(password, user.password);

  if (!validPassword) {
    return res.render("login", { error: "Invalid  password" });
  }

  req.session.user = {
    id: user.id,
    username: user.username,
  };

  await recordAudit(user.id, "User Login", "Successful login");

  res.redirect("/evidence/dashboard");
});

router.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});

module.exports = router;
