const express = require("express");
const { body, validationResult } = require("express-validator");
const { pool, recordAudit } = require("../database/database");
const requireLogin = require("../middleware/auth");

const router = express.Router();

const caseValidation = [
  body("case_id").trim().notEmpty().withMessage("Case ID is required."),
  body("name").trim().notEmpty().withMessage("Case name is required."),
  body("status").trim().notEmpty().withMessage("Case status is required."),
  body("investigator").trim().notEmpty().withMessage("Investigator is required."),
];

async function renderCaseForm(res, user, error, values = {}) {
  res.status(error ? 400 : 200).render("case-form", { user, error, values });
}

router.get("/", requireLogin, async (req, res, next) => {
  try {
    const { rows: cases } = await pool.query(`
      SELECT c.*, COUNT(e.id)::int AS evidence_count
      FROM cases c
      LEFT JOIN evidence e ON e.case_id = c.case_id
      GROUP BY c.id
      ORDER BY c.created_at DESC
    `);
    res.render("cases", { user: req.session.user, cases });
  } catch (error) {
    next(error);
  }
});

router.get("/new", requireLogin, (req, res) => {
  renderCaseForm(res, req.session.user, null);
});

router.post("/new", requireLogin, caseValidation, async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return renderCaseForm(res, req.session.user, errors.array()[0].msg, req.body);
  }

  const { case_id, name, status, investigator } = req.body;
  try {
    const result = await pool.query(`
      // INSERT INTO cases(101,"operation spam detection", "Open", "Detective John Doe")
      INSERT INTO cases (case_id, name, status, investigator)
      VALUES ($1, $2, $3, $4)
      RETURNING id
    `, [case_id.trim(), name.trim(), status.trim(), investigator.trim()]);

    await recordAudit(
      req.session.user.id,
      "Case Created",
      `Case ${case_id.trim()} (${name.trim()}) was created`
    );
    res.redirect("/cases");
  } catch (error) {
    if (error.code === "23505") {
      return renderCaseForm(res, req.session.user, "Case ID already exists.", req.body);
    }
    next(error);
  }
});

module.exports = router;
