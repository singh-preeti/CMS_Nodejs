const express = require("express");
const { body, validationResult } = require("express-validator");
const { pool, recordAudit } = require("../database/database");
const requireLogin = require("../middleware/auth");

const router = express.Router();

const evidenceValidation = [
  body("evidence_code").trim().notEmpty().withMessage("Evidence code is required."),
  body("case_id").trim().notEmpty().withMessage("Case ID is required."),
  body("type").trim().notEmpty().withMessage("Evidence type is required."),
  body("description").trim().isLength({ min: 5 }).withMessage("Description must be at least 5 characters long."),
  body("collected_by").trim().notEmpty().withMessage("Collector name is required."),
  body("location").trim().notEmpty().withMessage("Location is required."),
];

router.get("/dashboard", requireLogin, async (req, res, next) => {
  try {
    const { rows: evidence } = await pool.query(
      "SELECT * FROM evidence ORDER BY created_at DESC"
    );

    res.render("dashboard", {
      user: req.session.user,
      evidence,
    });
  } catch (error) {
    next(error);
  }
});

router.get("/new", requireLogin, async (req, res, next) => {
  try {
    const { rows: cases } = await pool.query(
      "SELECT * FROM cases ORDER BY created_at DESC"
    );
    res.render("evidence-form", {
      user: req.session.user,
      error: null,
      values: {},
      cases,
    });
  } catch (error) {
    next(error);
  }
});

router.post("/new", requireLogin, evidenceValidation, async (req, res) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const { rows: cases } = await pool.query(
      "SELECT * FROM cases ORDER BY created_at DESC"
    );
    return res.status(400).render("evidence-form", {
      user: req.session.user,
      error: errors.array()[0].msg,
      values: req.body,
      cases,
    });
  }

  const {
    evidence_code,
    case_id,
    type,
    description,
    collected_by,
    location,
  } = req.body;

  try {
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const result = await client.query(`
        INSERT INTO evidence (
          evidence_code,
          case_id,
          type,
          description,
          collected_by,
          location,
          status
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING id
      `, [
        evidence_code.trim(),
        case_id.trim(),
        type.trim(),
        description.trim(),
        collected_by.trim(),
        location.trim(),
        "Collected"
      ]);

      await client.query(`
      INSERT INTO custody (evidence_id, action, performed_by, notes)
      VALUES ($1, $2, $3, $4)
    `, [
      result.rows[0].id,
      "Evidence Collected",
      req.session.user.username,
      "Initial evidence registration"
      ]);
      await recordAudit(
        req.session.user.id,
        "Evidence Created",
        `Evidence ${evidence_code.trim()} was registered for case ${case_id.trim()}`,
        client
      );
      await client.query("COMMIT");
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }

    res.redirect("/evidence/dashboard");
  } catch (error) {
    console.error(error);
    const { rows: cases } = await pool.query(
      "SELECT * FROM cases ORDER BY created_at DESC"
    );
    res.status(400).render("evidence-form", {
      user: req.session.user,
      error: "Evidence code already exists or data is invalid.",
      values: req.body,
      cases,
    });
  }
});

router.get("/:id", requireLogin, async (req, res, next) => {
  try {
    const { rows: evidenceRows } = await pool.query(
      "SELECT * FROM evidence WHERE id = $1",
      [req.params.id]
    );
    const evidence = evidenceRows[0];

  if (!evidence) {
    return res.status(404).send("Evidence not found");
  }

    const { rows: custody } = await pool.query(`
      SELECT * FROM custody WHERE evidence_id = $1 ORDER BY created_at ASC
    `, [req.params.id]);

    res.render("evidence-details", {
      evidence,
      custody,
      user: req.session.user,
    });
  } catch (error) {
    next(error);
  }
});

router.post("/:id/status", requireLogin, async (req, res, next) => {
  const { status, notes } = req.body;

  if (!status || !status.trim()) {
    return res.status(400).send("Status is required");
  }

  try {
    const { rows } = await pool.query(
      "SELECT * FROM evidence WHERE id = $1",
      [req.params.id]
    );
    const evidence = rows[0];

  if (!evidence) {
    return res.status(404).send("Evidence not found");
  }

    await pool.query(
      "UPDATE evidence SET status = $1 WHERE id = $2",
      [status.trim(), req.params.id]
    );

    await pool.query(`
    INSERT INTO custody (evidence_id, action, performed_by, notes)
    VALUES ($1, $2, $3, $4)
  `, [
    req.params.id,
    `Status Updated: ${status.trim()}`,
    req.session.user.username,
    notes ? notes.trim() : "Status updated by investigator"
    ]);

    await recordAudit(
      req.session.user.id,
      "Evidence Status Updated",
      `Evidence ${evidence.evidence_code} status changed to ${status.trim()}`
    );

    res.redirect(`/evidence/${req.params.id}`);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
