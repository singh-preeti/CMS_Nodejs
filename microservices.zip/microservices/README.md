# Evidence Management Microservices

This version demonstrates three independently deployable Node.js services.
There is no API gateway and no Docker. Each service owns its UI, API, process,
and PostgreSQL database.

Ports:

- `user-service` and Users UI - port `3000`
- `case-service` and Cases UI - port `3001`
- `evidence-service` and Evidence UI - port `3002`

Each backend owns a separate PostgreSQL database: `case_db`, `evidence_db`, and
`user_db`. The database schemas are in each service's `db/schema.sql` folder.
Each service has EJS views in its own `views` folder and shared styling in its
own `public/styles.css` file.

See [SERVICE-COMMUNICATION.md](SERVICE-COMMUNICATION.md) for the detailed
communication flows and request examples.

Service communication is direct HTTP:

- Case service calls User service to load investigators.
- Case service calls Evidence service to load evidence for a case.
- Evidence service calls Case service for case information and User service for upload users.
- Each page links directly to the other service's port so the distributed design is visible.

## Run locally without Docker

Prerequisites: Node.js 18+, PostgreSQL, and the PostgreSQL command-line tools
(`createdb` and `psql`) available in PowerShell.

Create the databases and apply each service's schema:

```powershell
createdb -U postgres case_db
createdb -U postgres evidence_db
createdb -U postgres user_db

psql -U postgres -d case_db -f .\case-service\db\schema.sql
psql -U postgres -d evidence_db -f .\evidence-service\db\schema.sql
psql -U postgres -d user_db -f .\user-service\db\schema.sql
```

If a database already exists, skip its `createdb` command. PostgreSQL will ask
for the password of the `postgres` user.

Start each service in a separate PowerShell terminal:

```powershell
# Terminal 1: User service and Users UI
cd user-service
$env:DB_NAME = 'user_db'
$env:PORT = '3000'
npm install
npm start

# Terminal 2: Case service and Cases UI
cd case-service
$env:DB_NAME = 'case_db'
$env:PORT = '3001'
npm install
npm start

# Terminal 3: Evidence service and Evidence UI
cd evidence-service
$env:DB_NAME = 'evidence_db'
$env:PORT = '3002'
npm install
npm start
```

Then open these pages:

- `http://localhost:3000/users`
- `http://localhost:3001/cases`
- `http://localhost:3002/evidence`

The EJS UIs provide screens for creating users and cases, uploading evidence,
viewing case/evidence details, and recording custody transfers.

For separate servers, configure the direct service URLs for example:

```env
USER_SERVICE_URL=http://10.0.0.11:3000
CASE_SERVICE_URL=http://10.0.0.12:3001
EVIDENCE_SERVICE_URL=http://10.0.0.13:3002
```