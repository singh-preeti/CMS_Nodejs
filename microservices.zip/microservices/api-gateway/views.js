const express = require('express');
const multer = require('multer');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 * 1024 } });
const services = {
  users: process.env.USER_SERVICE_URL || 'http://localhost:3003',
  cases: process.env.CASE_SERVICE_URL || 'http://localhost:3001',
  evidence: process.env.EVIDENCE_SERVICE_URL || 'http://localhost:3002',
};

async function request(service, endpoint, options = {}) {
  const response = await fetch(`${services[service]}${endpoint}`, options);
  const body = await response.text();
  let data;
  try { data = body ? JSON.parse(body) : null; } catch { data = body; }
  if (!response.ok) throw new Error(data?.error || 'Service request failed');
  return data;
}

function renderError(res, view, data, error) {
  return res.status(400).render(view, { ...data, error: error.message || 'Request failed' });
}

router.get('/', (req, res) => res.redirect('/dashboard'));
router.get('/dashboard', async (req, res) => {
  try {
    const [cases, users] = await Promise.all([request('cases', '/cases'), request('users', '/users')]);
    res.render('dashboard', { title: 'Dashboard', page: 'dashboard', cases, users });
  } catch (error) { res.status(502).send(error.message); }
});

router.get('/users', async (req, res) => {
  try { res.render('users', { title: 'Users', page: 'users', users: await request('users', '/users'), error: null, values: {} }); }
  catch (error) { res.status(502).send(error.message); }
});
router.post('/users', async (req, res) => {
  try { await request('users', '/users', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(req.body) }); res.redirect('/users'); }
  catch (error) { const users = await request('users', '/users'); renderError(res, 'users', { title: 'Users', page: 'users', users, values: req.body || {} }, error); }
});

router.get('/cases', async (req, res) => {
  try {
    const [cases, users] = await Promise.all([request('cases', '/cases'), request('users', '/users')]);
    res.render('cases', { title: 'Cases', page: 'cases', cases, users, error: null, values: {} });
  } catch (error) { res.status(502).send(error.message); }
});
router.post('/cases', async (req, res) => {
  try { await request('cases', '/cases', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...req.body, investigatorId: Number(req.body.investigatorId) || null }) }); res.redirect('/cases'); }
  catch (error) {
    const [cases, users] = await Promise.all([request('cases', '/cases'), request('users', '/users')]);
    renderError(res, 'cases', { title: 'Cases', page: 'cases', cases, users, values: req.body || {} }, error);
  }
});
router.get('/cases/:id', async (req, res) => {
  try {
    const caseData = await request('cases', `/cases/${req.params.id}`);
    caseData.evidence = await request('evidence', `/evidence?caseId=${encodeURIComponent(req.params.id)}`);
    res.render('case-details', { title: caseData.case_number, page: 'cases', caseData });
  } catch (error) { res.status(404).send(error.message); }
});

router.get('/evidence', async (req, res) => {
  try { res.render('evidence', { title: 'Evidence', page: 'evidence', evidence: await request('evidence', '/evidence'), error: null }); }
  catch (error) { res.status(502).send(error.message); }
});
router.get('/evidence/new', async (req, res) => {
  try {
    const [cases, users] = await Promise.all([request('cases', '/cases'), request('users', '/users')]);
    res.render('evidence-form', { title: 'Upload Evidence', page: 'evidence', cases, users, error: null, values: {} });
  } catch (error) { res.status(502).send(error.message); }
});
router.post('/evidence/new', upload.single('file'), async (req, res) => {
  try {
    const form = new FormData();
    if (req.file) form.append('file', new Blob([req.file.buffer]), req.file.originalname);
    for (const [key, value] of Object.entries(req.body || {})) form.append(key, value);
    await request('evidence', '/evidence/upload', { method: 'POST', body: form });
    res.redirect('/evidence');
  } catch (error) {
    const [cases, users] = await Promise.all([request('cases', '/cases'), request('users', '/users')]);
    renderError(res, 'evidence-form', { title: 'Upload Evidence', page: 'evidence', cases, users, values: req.body || {} }, error);
  }
});
router.get('/evidence/:id', async (req, res) => {
  try {
    const evidence = await request('evidence', `/evidence/${req.params.id}`);
    const [custody, caseData] = await Promise.all([
      request('evidence', `/evidence/${req.params.id}/custody`),
      request('cases', `/cases/${evidence.case_id}`),
    ]);
    evidence.case_number = caseData.case_number;
    res.render('evidence-details', { title: evidence.evidence_number, page: 'evidence', evidence, custody, error: null });
  } catch (error) { res.status(404).send(error.message); }
});
router.post('/evidence/:id/transfer', async (req, res) => {
  try {
    await request('evidence', `/evidence/${req.params.id}/transfer`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...req.body, fromUser: Number(req.body.fromUser), toUser: Number(req.body.toUser) }) });
    res.redirect(`/evidence/${req.params.id}`);
  } catch (error) { res.status(400).send(error.message); }
});

module.exports = router;