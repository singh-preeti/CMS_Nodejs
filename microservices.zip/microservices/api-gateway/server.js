require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const viewRoutes = require('./views');

const app = express();
const services = {
  users: process.env.USER_SERVICE_URL || 'http://localhost:3003',
  cases: process.env.CASE_SERVICE_URL || 'http://localhost:3001',
  evidence: process.env.EVIDENCE_SERVICE_URL || 'http://localhost:3002',
};
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 * 1024 } });
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(viewRoutes);

async function proxyJson(res, url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.text();
  res.status(response.status).type(response.headers.get('content-type') || 'application/json').send(body);
}
function forward(service, path) { return (req, res, next) => proxyJson(res, `${services[service]}${path(req)}`, { method: req.method, headers: { 'content-type': 'application/json' }, body: ['GET', 'HEAD'].includes(req.method) ? undefined : JSON.stringify(req.body) }).catch(next); }

app.get('/api/health', async (req, res) => {
  const checks = await Promise.all(Object.entries(services).map(async ([name, url]) => {
    try { const response = await fetch(`${url}/health`); return [name, response.ok ? 'up' : 'down']; } catch { return [name, 'down']; }
  }));
  res.json({ app: 'Evidence Management API', status: 'running', services: Object.fromEntries(checks) });
});
app.get('/api/users', forward('users', () => '/users'));
app.post('/api/users', forward('users', () => '/users'));
app.get('/api/cases', forward('cases', () => '/cases'));
app.get('/api/cases/:id', async (req, res, next) => {
  try {
    const [caseResponse, evidenceResponse] = await Promise.all([
      fetch(`${services.cases}/cases/${req.params.id}`),
      fetch(`${services.evidence}/evidence?caseId=${encodeURIComponent(req.params.id)}`),
    ]);
    const caseData = await caseResponse.json();
    if (!caseResponse.ok) return res.status(caseResponse.status).json(caseData);
    caseData.evidence = evidenceResponse.ok ? await evidenceResponse.json() : [];
    res.json(caseData);
  } catch (error) { next(error); }
});
app.post('/api/cases', forward('cases', () => '/cases'));
app.get('/api/evidence', forward('evidence', () => '/evidence'));
app.get('/api/evidence/:id', forward('evidence', req => `/evidence/${req.params.id}`));
app.get('/api/evidence/:id/custody', forward('evidence', req => `/evidence/${req.params.id}/custody`));
app.post('/api/evidence/:id/transfer', forward('evidence', req => `/evidence/${req.params.id}/transfer`));
app.post('/api/evidence/:id/verify', forward('evidence', req => `/evidence/${req.params.id}/verify`));
app.post('/api/evidence/upload', upload.single('file'), async (req, res, next) => {
  try {
    const form = new FormData();
    form.append('file', new Blob([req.file.buffer]), req.file.originalname);
    for (const [key, value] of Object.entries(req.body || {})) form.append(key, value);
    await proxyJson(res, `${services.evidence}/evidence/upload`, { method: 'POST', body: form });
  } catch (error) { next(error); }
});
app.use((error, req, res, next) => { console.error(error); res.status(502).json({ error: 'Service unavailable' }); });
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`API gateway listening on ${port}`));