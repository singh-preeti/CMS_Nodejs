require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost', port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'user_db', user: process.env.DB_USER || 'postgres', password: process.env.DB_PASSWORD || 'mysql',
});
const serviceLinks = {
  users: process.env.USER_SERVICE_PUBLIC_URL || 'http://localhost:3000',
  cases: process.env.CASE_SERVICE_PUBLIC_URL || 'http://localhost:3001',
  evidence: process.env.EVIDENCE_SERVICE_PUBLIC_URL || 'http://localhost:3002',
};

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.locals.serviceLinks = serviceLinks;

async function listUsers() {
  return (await pool.query('SELECT id, username, role, created_at FROM users ORDER BY id')).rows;
}
async function createUser(body) {
  const { username, password, role } = body || {};
  if (!username?.trim() || !password?.trim()) throw new Error('Username and password are required');
  return (await pool.query(
    'INSERT INTO users (username, password, role) VALUES ($1, $2, $3) RETURNING id, username, role, created_at',
    [username.trim(), password.trim(), role?.trim() || 'investigator'],
  )).rows[0];
}

app.get('/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ service: 'user-service', status: 'running', port: 3000 }); }
  catch (error) { res.status(503).json({ service: 'user-service', status: 'unavailable', error: error.message }); }
});
app.get('/api/users', async (req, res, next) => { try { res.json(await listUsers()); } catch (error) { next(error); } });
app.post('/api/users', async (req, res) => {
  try { res.status(201).json(await createUser(req.body)); }
  catch (error) { res.status(error.code === '23505' ? 409 : 400).json({ error: error.code === '23505' ? 'Username already exists' : error.message }); }
});

app.get('/', (req, res) => res.redirect('/users'));
app.get('/users', async (req, res) => {
  try { res.render('users', { title: 'Users', page: 'users', users: await listUsers(), error: null, values: {} }); }
  catch (error) { res.status(500).send(error.message); }
});
app.post('/users', async (req, res) => {
  try { await createUser(req.body); res.redirect('/users'); }
  catch (error) { res.status(400).render('users', { title: 'Users', page: 'users', users: await listUsers(), error: error.message, values: req.body || {} }); }
});

app.use((error, req, res, next) => { console.error(error); res.status(500).json({ error: 'User service request failed' }); });
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`User service listening on ${port}`));
