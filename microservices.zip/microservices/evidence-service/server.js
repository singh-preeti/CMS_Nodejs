require('dotenv').config();
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { Pool } = require('pg');

const app = express();
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost', port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'evidence_db', user: process.env.DB_USER || 'postgres', password: process.env.DB_PASSWORD || 'mysql',
});
const uploadDir = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, 'uploads'));
fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 * 1024 } });
const serviceLinks = {
  users: process.env.USER_SERVICE_PUBLIC_URL || 'http://localhost:3000',
  cases: process.env.CASE_SERVICE_PUBLIC_URL || 'http://localhost:3001',
  evidence: process.env.EVIDENCE_SERVICE_PUBLIC_URL || 'http://localhost:3002',
};
const caseServiceUrl = process.env.CASE_SERVICE_URL || 'http://localhost:3001';
const userServiceUrl = process.env.USER_SERVICE_URL || 'http://localhost:3000';

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.locals.serviceLinks = serviceLinks;
app.get('/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ service: 'evidence-service', status: 'running', port: 3002, communicatesWith: ['user-service', 'case-service'] }); }
  catch (error) { res.status(503).json({ service: 'evidence-service', status: 'unavailable', error: error.message }); }
});
app.get('/api/evidence', async (req, res, next) => {
  try {
    const query = req.query.caseId ? 'SELECT * FROM evidence WHERE case_id = $1 ORDER BY id DESC' : 'SELECT * FROM evidence ORDER BY id DESC';
    const values = req.query.caseId ? [req.query.caseId] : [];
    res.json((await pool.query(query, values)).rows);
  } catch (error) { next(error); }
});
app.get('/api/evidence/:id', async (req, res, next) => {
  try {
    const result = await pool.query('SELECT * FROM evidence WHERE id = $1', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Evidence not found' });
    res.json(result.rows[0]);
  } catch (error) { next(error); }
});
app.post('/api/evidence/upload', upload.single('file'), async (req, res, next) => {
  try {
    const file = req.file;
    const { caseId, type, uploadedBy } = req.body || {};
    if (!file) return res.status(400).json({ error: 'File is required' });
    if (!caseId) return res.status(400).json({ error: 'caseId is required' });
    if (!type?.trim()) return res.status(400).json({ error: 'Evidence type is required' });
    const sha256 = crypto.createHash('sha256').update(file.buffer).digest('hex');
    const duplicate = await pool.query('SELECT id FROM evidence WHERE sha256 = $1', [sha256]);
    if (duplicate.rows[0]) return res.status(400).json({ error: 'Duplicate evidence hash detected' });
    const storedPath = path.join(uploadDir, `${Date.now()}-${file.originalname.replace(/\s+/g, '_')}`);
    fs.writeFileSync(storedPath, file.buffer);
    const evidence = await pool.query(
      `INSERT INTO evidence (evidence_number, case_id, file_name, stored_path, file_type, file_size, sha256, uploaded_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [`EVD-${Date.now()}`, caseId, file.originalname, storedPath, type.trim(), file.size, sha256, Number(uploadedBy || 1)],
    );
    const record = evidence.rows[0];
    await pool.query(
      `INSERT INTO custody_entries (evidence_id, from_user, to_user, movement_type, reason) VALUES ($1, $2, $2, 'received', 'Initial evidence intake')`,
      [record.id, Number(uploadedBy || 1)],
    );
    res.status(201).json({ evidenceId: record.id, evidenceNumber: record.evidence_number, fileName: record.file_name, hash: sha256, status: record.status });
  } catch (error) { next(error); }
});
app.get('/api/evidence/:id/custody', async (req, res, next) => {
  try { res.json((await pool.query('SELECT * FROM custody_entries WHERE evidence_id = $1 ORDER BY created_at', [req.params.id])).rows); } catch (error) { next(error); }
});
app.post('/api/evidence/:id/transfer', async (req, res, next) => {
  try {
    const { fromUser, toUser, reason } = req.body || {};
    if (!fromUser || !toUser || fromUser === toUser) return res.status(400).json({ error: 'Transfer requires different sender and recipient' });
    const result = await pool.query(
      `INSERT INTO custody_entries (evidence_id, from_user, to_user, movement_type, reason) VALUES ($1, $2, $3, 'transferred', $4) RETURNING *`,
      [req.params.id, fromUser, toUser, reason || null],
    );
    res.json(result.rows[0]);
  } catch (error) { next(error); }
});
app.post('/api/evidence/:id/verify', async (req, res, next) => {
  try {
    const result = await pool.query('SELECT sha256 FROM evidence WHERE id = $1', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Evidence not found' });
    res.json({ valid: result.rows[0].sha256 === req.body?.hash, storedHash: result.rows[0].sha256 });
  } catch (error) { next(error); }
});
app.use((error, req, res, next) => { console.error(error); res.status(500).json({ error: 'Evidence service request failed' }); });
async function requestJson(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Connected service request failed');
  return data;
}
app.get('/', (req, res) => res.redirect('/evidence'));
app.get('/evidence', async (req, res) => {
  try {
    const evidence = await requestJson(`${serviceLinks.evidence}/api/evidence`);
    const cases = await requestJson(`${caseServiceUrl}/api/cases`);
    const caseNames = new Map(cases.map(item => [String(item.id), item.case_number]));
    evidence.forEach(item => { item.case_number = caseNames.get(String(item.case_id)) || item.case_id; });
    res.render('evidence', { title: 'Evidence', page: 'evidence', evidence, error: null });
  } catch (error) { res.status(502).send(error.message); }
});
app.get('/evidence/new', async (req, res) => {
  try {
    const [cases, users] = await Promise.all([requestJson(`${caseServiceUrl}/api/cases`), requestJson(`${userServiceUrl}/api/users`)]);
    res.render('evidence-form', { title: 'Upload Evidence', page: 'evidence', cases, users, error: null, values: {} });
  } catch (error) { res.status(502).send(error.message); }
});
app.post('/evidence/new', upload.single('file'), async (req, res) => {
  try {
    const form = new FormData();
    if (req.file) form.append('file', new Blob([req.file.buffer]), req.file.originalname);
    for (const [key, value] of Object.entries(req.body || {})) form.append(key, value);
    await requestJson(`${serviceLinks.evidence}/api/evidence/upload`, { method: 'POST', body: form });
    res.redirect('/evidence');
  } catch (error) { res.status(400).send(error.message); }
});
app.get('/evidence/:id', async (req, res) => {
  try {
    const evidence = await requestJson(`${serviceLinks.evidence}/api/evidence/${req.params.id}`);
    const [custody, caseData] = await Promise.all([
      requestJson(`${serviceLinks.evidence}/api/evidence/${req.params.id}/custody`),
      requestJson(`${caseServiceUrl}/api/cases/${evidence.case_id}`),
    ]);
    evidence.case_number = caseData.case_number;
    res.render('evidence-details', { title: evidence.evidence_number, page: 'evidence', evidence, custody, error: null });
  } catch (error) { res.status(404).send(error.message); }
});
app.post('/evidence/:id/transfer', async (req, res) => {
  try { await requestJson(`${serviceLinks.evidence}/api/evidence/${req.params.id}/transfer`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(req.body) }); res.redirect(`/evidence/${req.params.id}`); }
  catch (error) { res.status(400).send(error.message); }
});
const port = process.env.PORT || 3002;
app.listen(port, () => console.log(`Evidence service listening on ${port}`));