CREATE TABLE IF NOT EXISTS evidence (
  id SERIAL PRIMARY KEY,
  evidence_number VARCHAR(50) UNIQUE NOT NULL,
  case_id INTEGER NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  stored_path VARCHAR(500) NOT NULL,
  file_type VARCHAR(100),
  file_size BIGINT,
  sha256 VARCHAR(128),
  status VARCHAR(50) DEFAULT 'uploaded',
  uploaded_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS custody_entries (
  id SERIAL PRIMARY KEY,
  evidence_id INTEGER REFERENCES evidence(id) ON DELETE CASCADE,
  from_user INTEGER,
  to_user INTEGER,
  movement_type VARCHAR(50) NOT NULL,
  reason TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);