require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost', port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'case_db', user: process.env.DB_USER || 'postgres', password: process.env.DB_PASSWORD || 'mysql',
});
const serviceLinks = {
  users: process.env.USER_SERVICE_PUBLIC_URL || 'http://localhost:3000',
  cases: process.env.CASE_SERVICE_PUBLIC_URL || 'http://localhost:3001',
  evidence: process.env.EVIDENCE_SERVICE_PUBLIC_URL || 'http://localhost:3002',
};
const evidenceServiceUrl = process.env.EVIDENCE_SERVICE_URL || 'http://localhost:3002';
const userServiceUrl = process.env.USER_SERVICE_URL || 'http://localhost:3000';

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.locals.serviceLinks = serviceLinks;

async function requestJson(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Connected service request failed');
  return data;
}
async function listCases() { return (await pool.query('SELECT * FROM cases ORDER BY id DESC')).rows; }
async function listUsers() { return requestJson(`${userServiceUrl}/api/users`); }
async function createCase(body) {
  const { title, investigatorId, caseNumber } = body || {};
  if (!title?.trim()) throw new Error('Case title is required');
  return (await pool.query(
    'INSERT INTO cases (case_number, title, investigator_id) VALUES ($1, $2, $3) RETURNING *',
    [caseNumber || `CASE-${Date.now()}`, title.trim(), investigatorId || null],
  )).rows[0];
}

app.get('/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ service: 'case-service', status: 'running', port: 3001, communicatesWith: ['user-service', 'evidence-service'] }); }
  catch (error) { res.status(503).json({ service: 'case-service', status: 'unavailable', error: error.message }); }
});
app.get('/api/cases', async (req, res, next) => { try { res.json(await listCases()); } catch (error) { next(error); } });
app.get('/api/cases/:id', async (req, res, next) => {
  try {
    const result = await pool.query('SELECT * FROM cases WHERE id = $1', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Case not found' });
    res.json(result.rows[0]);
  } catch (error) { next(error); }
});
app.post('/api/cases', async (req, res) => { try { res.status(201).json(await createCase(req.body)); } catch (error) { res.status(400).json({ error: error.message }); } });

app.get('/', (req, res) => res.redirect('/cases'));
app.get('/cases', async (req, res) => {
  try { res.render('cases', { title: 'Cases', page: 'cases', cases: await listCases(), users: await listUsers(), error: null, values: {} }); }
  catch (error) { res.status(502).send(error.message); }
});
app.post('/cases', async (req, res) => {
  try { await createCase({ ...req.body, investigatorId: Number(req.body.investigatorId) || null }); res.redirect('/cases'); }
  catch (error) { res.status(400).render('cases', { title: 'Cases', page: 'cases', cases: await listCases(), users: await listUsers(), error: error.message, values: req.body || {} }); }
});
app.get('/cases/:id', async (req, res) => {
  try {
    const caseData = await requestJson(`http://localhost:${port}/api/cases/${req.params.id}`);
    caseData.evidence = await requestJson(`${evidenceServiceUrl}/api/evidence?caseId=${encodeURIComponent(req.params.id)}`);
    res.render('case-details', { title: caseData.case_number, page: 'cases', caseData });
  } catch (error) { res.status(404).send(error.message); }
});

app.use((error, req, res, next) => { console.error(error); res.status(500).json({ error: 'Case service request failed' }); });
const port = process.env.PORT || 3001;
app.listen(port, () => console.log(`Case service listening on ${port}`));
