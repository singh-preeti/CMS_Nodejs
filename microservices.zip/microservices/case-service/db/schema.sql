CREATE TABLE IF NOT EXISTS cases (
  id SERIAL PRIMARY KEY,
  case_number VARCHAR(50) UNIQUE NOT NULL,
  title VARCHAR(255) NOT NULL,
  status VARCHAR(50) DEFAULT 'open',
  investigator_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO cases (case_number, title, status, investigator_id)
VALUES ('CASE-001', 'Evidence intake for suspicious activity', 'open', 1)
ON CONFLICT (case_number) DO NOTHING;