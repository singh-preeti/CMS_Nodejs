# Keycloak Guide

This project uses Keycloak for login and user authentication.

## Official Links

- [Download Keycloak](https://www.keycloak.org/downloads)
- [Keycloak Getting Started](https://www.keycloak.org/getting-started)
- [Keycloak Documentation](https://www.keycloak.org/documentation)

## Requirements

- Java 17 or newer
- Node.js 18 or newer
- Windows PowerShell

Check Java:

```powershell
java -version
```

## Install Keycloak Locally

1. Download the Keycloak server ZIP from the [Keycloak downloads page](https://www.keycloak.org/downloads).
2. Extract it into the project folder.
3. Rename the extracted folder to `keycloak-local`.

This file should exist:

```text
keycloak-local\bin\kc.bat
```

## Start Keycloak

Open PowerShell in the project folder and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start-keycloak-local.ps1
```

Keycloak starts at:

```text
http://127.0.0.1:8080
```

The script imports [keycloak/realm-export.json](keycloak/realm-export.json). This creates the `forensic` realm, the `forensic-app` client, redirect URIs, and a test user.

Test login:

```text
Username: investigator
Password: investigator
```

## Start the Node.js App

Open a second PowerShell terminal:

```powershell
npm install
npm start
```

Open:

```text
http://127.0.0.1:3004
```

Use the same host during login. Do not switch between `localhost` and `127.0.0.1`.

## Where Keycloak Is Used

The Node.js adapter is listed in [package.json](package.json):

```text
keycloak-connect
```

Keycloak is used in [server.js](server.js):

- `new Keycloak(...)` connects to the `forensic` realm.
- `keycloak.middleware()` handles the login callback.
- `keycloak.protect()` protects `/dashboard`.
- `keycloak.protect()` protects `POST /cases`.
- `req.kauth.grant` contains the logged-in user.

## Important Files

| File or folder | Purpose |
| --- | --- |
| `keycloak-local` | Local Keycloak server |
| `keycloak/realm-export.json` | Realm, client, and user settings |
| `start-keycloak-local.ps1` | Starts Keycloak and imports the realm |
| `server.js` | Connects Express to Keycloak |
| `.env` | Local app and Keycloak settings |

Keep the Keycloak terminal running while using the Node.js app.
