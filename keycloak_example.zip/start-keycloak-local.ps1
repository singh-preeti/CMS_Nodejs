$ErrorActionPreference = 'Stop'

$keycloakHome = Join-Path $PSScriptRoot 'keycloak-local'
$realmFile = Join-Path $PSScriptRoot 'keycloak\realm-export.json'
$importDirectory = Join-Path $keycloakHome 'data\import'

if (-not (Test-Path (Join-Path $keycloakHome 'bin\kc.bat'))) {
  throw "Local Keycloak was not found in $keycloakHome."
}

New-Item -ItemType Directory -Path $importDirectory -Force | Out-Null
Copy-Item $realmFile (Join-Path $importDirectory 'realm-export.json') -Force

Push-Location $keycloakHome
try {
  & '.\bin\kc.bat' start-dev --http-port 8080 --import-realm
} finally {
  Pop-Location
}