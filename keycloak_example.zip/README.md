# Traceboard

Simple forensic investigation case management UI built with Node.js, Express, and EJS. Dashboard routes are protected by Keycloak using `keycloak-connect`.

For the complete local Keycloak installation and integration guide, see [keyclock_guide.md](keyclock_guide.md).

## Why use Keycloak?

Keycloak provides the application's identity and access-management layer without requiring the Node app to store passwords or implement OAuth2/OpenID Connect itself. It gives this app:

- Single sign-on and a central login page.
- OpenID Connect tokens that identify the signed-in investigator.
- A place to manage users, roles, sessions, and future team permissions.
- A straightforward path from local development to a secured deployment.

The application still owns forensic case data and business rules. Keycloak owns authentication and identity.

## Install Keycloak locally on Windows

Official resources:

- [Keycloak downloads](https://www.keycloak.org/downloads)
- [Keycloak server administration guide](https://www.keycloak.org/server)
- [Keycloak securing applications guide](https://www.keycloak.org/securing-apps)
- [Microsoft OpenJDK downloads](https://learn.microsoft.com/en-us/java/openjdk/download)

### Prerequisites

- Windows PowerShell.
- Java 17 or newer. This project has been tested with Java 21.
- Node.js 18 or newer.

Check Java:

```powershell
java -version
```

### Automatic project setup

The repository includes a local Keycloak distribution in `keycloak-local` and a launcher script. Start Keycloak in one PowerShell terminal:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start-keycloak-local.ps1
```

The script starts Keycloak in development mode on `http://127.0.0.1:8080` and imports [keycloak/realm-export.json](keycloak/realm-export.json). The import creates:

- Realm: `forensic`
- Client: `forensic-app`
- Test username: `investigator`
- Test password: `investigator`

### Manual Keycloak installation

If `keycloak-local` is not present, download the latest supported Keycloak server archive from the [official downloads page](https://www.keycloak.org/downloads), extract it into this project as `keycloak-local`, then run:

```powershell
New-Item -ItemType Directory -Force .\keycloak-local\data\import
Copy-Item .\keycloak\realm-export.json .\keycloak-local\data\import\realm-export.json
Set-Location .\keycloak-local
.\bin\kc.bat start-dev --http-port 8080 --import-realm
```

## Run the Node.js app

In a second PowerShell terminal:

```powershell
npm install
npm start
```

Open `http://127.0.0.1:3004`. Use this exact host consistently during login so the session cookie is preserved.

Login with:

```text
Username: investigator
Password: investigator
```

## Where Keycloak is used in the code

Keycloak integration is in [server.js](server.js):

1. `require('keycloak-connect')` loads the Node.js Keycloak adapter.
2. `new Keycloak(...)` configures the realm, Keycloak server URL, client ID, and session store from `.env`.
3. `app.use(keycloak.middleware())` handles the Keycloak callback and stores the authenticated grant in the Express session.
4. `keycloak.protect()` protects `GET /dashboard`, so unauthenticated users are sent to Keycloak.
5. `keycloak.protect()` also protects `POST /cases`, so only authenticated investigators can create cases.
6. `req.kauth.grant.access_token.content.preferred_username` displays the authenticated investigator name and records the case lead.

The relevant configuration is in [.env.example](.env.example). The local realm, client, redirect URIs, and test user are defined in [keycloak/realm-export.json](keycloak/realm-export.json). The local startup process is defined in [start-keycloak-local.ps1](start-keycloak-local.ps1).

Case records are intentionally stored in memory for this starter app. Replace the `cases` array with a database repository when persistence is needed.