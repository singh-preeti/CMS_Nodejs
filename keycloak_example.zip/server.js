require('dotenv').config();

const path = require('path');
const express = require('express');
const session = require('express-session');
const Keycloak = require('keycloak-connect');

const app = express();
const port = Number(process.env.PORT || 3000);
const memoryStore = new session.MemoryStore();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'local-development-secret',
  resave: false,
  saveUninitialized: false,
  store: memoryStore,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' }
}));

const keycloak = new Keycloak({ store: memoryStore }, {
  realm: process.env.KEYCLOAK_REALM || 'forensic',
  'auth-server-url': process.env.KEYCLOAK_AUTH_SERVER_URL || 'http://localhost:8080',
  'ssl-required': process.env.KEYCLOAK_SSL_REQUIRED || 'none',
  resource: process.env.KEYCLOAK_CLIENT_ID || 'forensic-app',
  credentials: process.env.KEYCLOAK_CLIENT_SECRET
    ? { secret: process.env.KEYCLOAK_CLIENT_SECRET }
    : undefined,
  'public-client': !process.env.KEYCLOAK_CLIENT_SECRET,
  'confidential-port': 0
});

app.use(keycloak.middleware());

const cases = [
  {
    id: 'FI-2026-014',
    title: 'Unauthorized access review',
    status: 'Active',
    priority: 'High',
    lead: 'A. Morgan',
    updated: 'Today, 09:42',
    summary: 'Reviewing endpoint activity and access logs from a finance workstation.'
  },
  {
    id: 'FI-2026-011',
    title: 'Mobile device extraction',
    status: 'In review',
    priority: 'Medium',
    lead: 'J. Patel',
    updated: 'Yesterday, 16:18',
    summary: 'Evidence package is ready for timeline analysis and examiner notes.'
  },
  {
    id: 'FI-2026-008',
    title: 'Phishing incident response',
    status: 'Closed',
    priority: 'Low',
    lead: 'R. Chen',
    updated: 'Mar 18, 14:06',
    summary: 'Final report approved and chain-of-custody records archived.'
  }
];

app.get('/', (req, res) => res.render('landing', { user: req.kauth && req.kauth.grant }));

app.get('/dashboard', keycloak.protect(), (req, res) => {
  const username = req.kauth.grant.access_token.content.preferred_username || 'Investigator';
  res.render('dashboard', { cases, username });
});

app.post('/cases', keycloak.protect(), (req, res) => {
  const { title, priority, summary } = req.body;
  if (!title || !summary) return res.status(400).send('Title and summary are required.');

  cases.unshift({
    id: `FI-2026-${String(cases.length + 15).padStart(3, '0')}`,
    title: title.trim(),
    status: 'Active',
    priority: priority || 'Medium',
    lead: req.kauth.grant.access_token.content.preferred_username || 'Investigator',
    updated: 'Just now',
    summary: summary.trim()
  });
  res.redirect('/dashboard');
});

app.listen(port, () => {
  console.log(`Forensic Investigation App listening on http://localhost:${port}`);
});