const evidenceService = require('../services/evidenceService');

class EvidenceController {
  async list(req, res, next) { try { res.json(await evidenceService.getAllEvidence(req.query.caseId)); } catch (error) { next(error); } }
  async getById(req, res, next) { try { res.json(await evidenceService.getEvidenceById(req.params.id)); } catch (error) { res.status(error.message === 'Evidence not found' ? 404 : 502).json({ error: error.message }); } }
  async upload(req, res, next) { try { res.status(201).json(await evidenceService.uploadEvidence(req.file, req.body.caseId, req.body.type, Number(req.body.uploadedBy || 1))); } catch (error) { next(error); } }
  async custody(req, res, next) { try { res.json(await evidenceService.getCustodyHistory(req.params.id)); } catch (error) { next(error); } }
  async transfer(req, res, next) { try { res.json(await evidenceService.transferEvidence(req.params.id, req.body || {})); } catch (error) { res.status(400).json({ error: error.message }); } }
  async verify(req, res, next) { try { res.json(await evidenceService.verifyIntegrity(req.params.id, req.body?.hash)); } catch (error) { res.status(404).json({ error: error.message }); } }
}

module.exports = new EvidenceController();