const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const evidenceRepository = require('../repositories/evidenceRepository');
const custodyRepository = require('../repositories/custodyRepository');

const MAX_FILE_SIZE = 10 * 1024 * 1024 * 1024;
const caseServiceUrl = process.env.CASE_SERVICE_URL || 'http://localhost:3001';
const userServiceUrl = process.env.USER_SERVICE_URL || 'http://localhost:3000';
const uploadDir = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, '../../uploads'));
fs.mkdirSync(uploadDir, { recursive: true });

async function requestJson(url) {
  const response = await fetch(url);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Connected service request failed');
  return data;
}

class EvidenceService {
  async getAllEvidence(caseId) {
    const [evidence, cases] = await Promise.all([
      evidenceRepository.getAllEvidence(caseId),
      requestJson(`${caseServiceUrl}/api/cases`),
    ]);
    const caseNumbers = new Map(cases.map(item => [String(item.id), item.case_number]));
    return evidence.map(item => ({ ...item, case_number: caseNumbers.get(String(item.case_id)) || item.case_id }));
  }

  async getEvidenceById(evidenceId) {
    const evidence = await evidenceRepository.getEvidenceById(evidenceId);
    if (!evidence) throw new Error('Evidence not found');
    const caseData = await requestJson(`${caseServiceUrl}/api/cases/${evidence.case_id}`);
    return { ...evidence, case_number: caseData.case_number, case_title: caseData.title };
  }

  async getCustodyHistory(evidenceId) {
    const [history, users] = await Promise.all([custodyRepository.getCustodyHistory(evidenceId), requestJson(`${userServiceUrl}/api/users`)]);
    const names = new Map(users.map(user => [String(user.id), user.username]));
    return history.map(entry => ({ ...entry, from_username: names.get(String(entry.from_user)), to_username: names.get(String(entry.to_user)) }));
  }

  async uploadEvidence(file, caseId, fileType, uploadedBy) {
    if (!file) throw new Error('File is required');
    if (file.size > MAX_FILE_SIZE) throw new Error('File exceeds 10GB limit');
    if (!caseId) throw new Error('caseId is required');
    if (!fileType || !fileType.trim()) throw new Error('Evidence type is required');
    const fileBuffer = file.buffer || fs.readFileSync(file.path);
    const sha256 = crypto.createHash('sha256').update(fileBuffer).digest('hex');
    if (await evidenceRepository.findByHash(sha256)) throw new Error('Duplicate evidence hash detected');
    const storedPath = path.join(uploadDir, `${Date.now()}-${file.originalname.replace(/\s+/g, '_')}`);
    fs.writeFileSync(storedPath, fileBuffer);
    const record = await evidenceRepository.createEvidence({
      evidenceNumber: `EVD-${Date.now()}`, caseId, fileName: file.originalname, storedPath,
      fileType: fileType.trim(), fileSize: file.size, sha256, uploadedBy,
    });
    await custodyRepository.createCustodyEntry({ evidenceId: record.id, fromUser: uploadedBy, toUser: uploadedBy, movementType: 'received', reason: 'Initial evidence intake' });
    return { evidenceId: record.id, evidenceNumber: record.evidence_number, fileName: record.file_name, hash: sha256, status: record.status };
  }

  async transferEvidence(evidenceId, { fromUser, toUser, reason }) {
    if (!fromUser || !toUser || fromUser === toUser) throw new Error('Transfer requires different sender and recipient');
    return custodyRepository.createCustodyEntry({ evidenceId, fromUser, toUser, movementType: 'transferred', reason });
  }

  async verifyIntegrity(evidenceId, hash) {
    const evidence = await evidenceRepository.getEvidenceById(evidenceId);
    if (!evidence) throw new Error('Evidence not found');
    return { valid: evidence.sha256 === hash, storedHash: evidence.sha256 };
  }
}

module.exports = new EvidenceService();