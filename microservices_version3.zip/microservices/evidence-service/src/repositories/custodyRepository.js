const pool = require('../config/database');

class CustodyRepository {
  async getCustodyHistory(evidenceId) {
    return (await pool.query('SELECT * FROM custody_entries WHERE evidence_id = $1 ORDER BY created_at DESC', [evidenceId])).rows;
  }

  async createCustodyEntry({ evidenceId, fromUser, toUser, movementType, reason }) {
    return (await pool.query(
      'INSERT INTO custody_entries (evidence_id, from_user, to_user, movement_type, reason) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [evidenceId, fromUser, toUser, movementType, reason],
    )).rows[0];
  }
}

module.exports = new CustodyRepository();