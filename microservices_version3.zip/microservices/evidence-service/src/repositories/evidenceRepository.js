const pool = require('../config/database');

class EvidenceRepository {
  async getAllEvidence(caseId) {
    const query = caseId ? 'SELECT * FROM evidence WHERE case_id = $1 ORDER BY id DESC' : 'SELECT * FROM evidence ORDER BY id DESC';
    return (await pool.query(query, caseId ? [caseId] : [])).rows;
  }

  async getEvidenceById(evidenceId) {
    return (await pool.query('SELECT * FROM evidence WHERE id = $1', [evidenceId])).rows[0] || null;
  }

  async findByHash(sha256) {
    return (await pool.query('SELECT * FROM evidence WHERE sha256 = $1 LIMIT 1', [sha256])).rows[0] || null;
  }

  async createEvidence({ evidenceNumber, caseId, fileName, storedPath, fileType, fileSize, sha256, uploadedBy }) {
    return (await pool.query(
      `INSERT INTO evidence (evidence_number, case_id, file_name, stored_path, file_type, file_size, sha256, uploaded_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [evidenceNumber, caseId, fileName, storedPath, fileType, fileSize, sha256, uploadedBy],
    )).rows[0];
  }
}

module.exports = new EvidenceRepository();