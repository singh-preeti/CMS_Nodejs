# Service Communication Guide

This application runs as four independent Node.js services. There is no API gateway.
Each service has its own process, UI, REST API, and PostgreSQL database.

## Services

| Service | Port | UI | Database | Responsibility |
|---|---:|---|---|---|
| User service | `3000` | `http://localhost:3000/users` | `user_db` | Users and investigator accounts |
| Case service | `3001` | `http://localhost:3001/cases` | `case_db` | Investigation cases |
| Evidence service | `3002` | `http://localhost:3002/evidence` | `evidence_db` | Files, hashes, and custody history |
| Criminal service | `3003` | `http://localhost:3003/criminals` | `criminal_db` | Criminal records linked to cases |

The services communicate through HTTP. They do not share database tables.
For example, `case_db` stores `investigator_id`, but the investigator record
belongs to `user_db` and is retrieved from the User service when needed.

## When Services Communicate

### 1. Opening the Cases page

Request:

```text
GET http://localhost:3001/cases
```

The Case service performs two operations:

1. Reads cases from its own `case_db` database.
2. Calls the User service:

```text
GET http://localhost:3000/api/users
```

The User service returns the available investigators. The Case service uses
that response to populate the investigator dropdown in the EJS page.

### 2. Creating a case

The browser submits the form directly to the Case service:

```text
POST http://localhost:3001/cases
```

The Case service validates the title and stores the new case in `case_db`.
It does not write to `user_db`; it stores only the selected `investigator_id`.

### 3. Opening case details

Request:

```text
GET http://localhost:3001/cases/1
```

The Case service:

1. Reads case `1` from `case_db`.
2. Calls the Evidence service:

```text
GET http://localhost:3002/api/evidence?caseId=1
```

3. Combines the case and evidence data.
4. Renders the `case-details.ejs` view.

This is direct service-to-service communication. The browser does not need a
gateway to combine the data.

### 4. Opening the Evidence page

Request:

```text
GET http://localhost:3002/evidence
```

The Evidence service:

1. Reads evidence records from `evidence_db`.
2. Calls the Case service:

```text
GET http://localhost:3001/api/cases
```

3. Matches each `case_id` to a case number.
4. Renders the `evidence.ejs` view.

### 5. Opening the Evidence upload page

Request:

```text
GET http://localhost:3002/evidence/new
```

The Evidence service calls both services:

```text
GET http://localhost:3001/api/cases
GET http://localhost:3000/api/users
```

The responses populate the Case and Uploaded by dropdowns in the EJS form.

### 6. Uploading evidence

The browser submits the file directly to the Evidence service:

```text
POST http://localhost:3002/evidence/new
```

The Evidence service:

1. Validates the file, case, and uploader.
2. Calculates the SHA-256 hash.
3. Checks for duplicate hashes in `evidence_db`.
4. Saves the file under the Evidence service's `uploads` folder.
5. Stores evidence metadata in `evidence_db`.
6. Creates the initial custody entry in `evidence_db`.
7. Redirects the browser to the Evidence service's evidence list.

The upload itself does not need to call the Case or User service because the
browser already selected their IDs from those services.

### 7. Viewing evidence details

Request:

```text
GET http://localhost:3002/evidence/1
```

The Evidence service:

1. Reads the evidence record from `evidence_db`.
2. Reads custody history from `evidence_db`.
3. Calls the Case service:

```text
GET http://localhost:3001/api/cases/1
```

4. Adds the case number to the evidence data.
5. Renders `evidence-details.ejs`.

### 8. Transferring evidence custody

The browser submits the transfer form directly to the Evidence service:

```text
POST http://localhost:3002/evidence/1/transfer
```

The Evidence service validates the sender and recipient, then writes a new
custody entry to `evidence_db`. The User service is not called during the
transfer; the user IDs are already supplied by the form.

### 9. Opening the Criminals page

Request:

```text
GET http://localhost:3003/criminals
```

The Criminal service reads criminal records from `criminal_db` and calls the
Case service:

```text
GET http://localhost:3001/api/cases
```

It uses the response to display the related case number for each criminal.

### 10. Opening the Criminal form

Request:

```text
GET http://localhost:3003/criminals/new
```

The Criminal service calls both services to populate the form:

```text
GET http://localhost:3001/api/cases
GET http://localhost:3000/api/users
```

The selected case and creator IDs are stored as references in `criminal_db`.
The Criminal service does not write to the Case or User databases.

### 11. Viewing criminal details

Request:

```text
GET http://localhost:3003/criminals/1
```

The Criminal service reads the record from `criminal_db` and calls the Case
service for the case number and case title.

## Communication Diagram

```mermaid
flowchart LR
    Browser[Browser]
    Users[User service\nPort 3000\nuser_db]
    Cases[Case service\nPort 3001\ncase_db]
    Evidence[Evidence service\nPort 3002\nevidence_db]
    Criminals[Criminal service\nPort 3003\ncriminal_db]

    Browser -->|Users UI and API| Users
    Browser -->|Cases UI and API| Cases
    Browser -->|Evidence UI and API| Evidence
    Browser -->|Criminals UI and API| Criminals
    Cases -->|GET /api/users| Users
    Cases -->|GET /api/evidence?caseId=...| Evidence
    Evidence -->|GET /api/cases| Cases
    Evidence -->|GET /api/users| Users
    Criminals -->|GET /api/cases| Cases
    Criminals -->|GET /api/users| Users
```

## Health Checks

Each service exposes its own health endpoint:

```text
GET http://localhost:3000/health
GET http://localhost:3001/health
GET http://localhost:3002/health
GET http://localhost:3003/health
```

A healthy response has HTTP status `200` and identifies the service. The Case
and Evidence health responses also describe which services they communicate
with.

## What Happens if a Service Stops?

Because there is no gateway, the effect is easy to see:

- If the User service stops, the User UI stops working and the Case upload form
  cannot load its investigator list.
- If the Case service stops, the Cases UI stops working and Evidence pages
  cannot display case information.
- If the Evidence service stops, the Evidence UI stops working and Case detail
  pages cannot display their evidence list.
- If the Criminal service stops, criminal pages stop working, but Users, Cases,
  and Evidence remain available.
- A service's own database remains owned by that service. Other services do not
  connect directly to it.

This is the main microservices lesson demonstrated by this application: each
service can run on a different server, but dependent workflows need network
communication between those servers.

## Running the Services

Start them manually in four separate terminals:

```powershell
# Terminal 1
cd user-service
$env:DB_NAME = 'user_db'
$env:PORT = '3000'
npm start

# Terminal 2
cd case-service
$env:DB_NAME = 'case_db'
$env:PORT = '3001'
npm start

# Terminal 3
cd evidence-service
$env:DB_NAME = 'evidence_db'
$env:PORT = '3002'
npm start

# Terminal 4
cd criminal-service
$env:DB_NAME = 'criminal_db'
$env:PORT = '3003'
npm start
```
