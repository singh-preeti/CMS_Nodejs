const express = require('express');
const caseController = require('../controllers/caseController');

const router = express.Router();
router.get('/cases', caseController.getAllCases);
router.get('/cases/:id', caseController.getCaseById);
router.post('/cases', caseController.createCase);

module.exports = router;