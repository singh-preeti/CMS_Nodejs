const express = require('express');
const caseViewController = require('../controllers/caseViewController');

const router = express.Router();
router.get('/', (req, res) => res.redirect('/cases'));
router.get('/cases', caseViewController.list);
router.post('/cases', caseViewController.create);
router.get('/cases/:id', caseViewController.details);

module.exports = router;