const caseRepository = require('../repositories/caseRepository');

const userServiceUrl = process.env.USER_SERVICE_URL || 'http://localhost:3000';
const evidenceServiceUrl = process.env.EVIDENCE_SERVICE_URL || 'http://localhost:3002';

async function requestJson(url) {
  const response = await fetch(url);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Connected service request failed');
  return data;
}

class CaseService {
  async getAllCases() {
    const [cases, users] = await Promise.all([caseRepository.getAllCases(), requestJson(`${userServiceUrl}/api/users`)]);
    const userNames = new Map(users.map(user => [String(user.id), user.username]));
    return cases.map(item => ({ ...item, investigator_name: userNames.get(String(item.investigator_id)) || null }));
  }

  async getCaseById(caseId) {
    const caseData = await caseRepository.getCaseById(caseId);
    if (!caseData) throw new Error('Case not found');
    const [users, evidence] = await Promise.all([
      requestJson(`${userServiceUrl}/api/users`),
      requestJson(`${evidenceServiceUrl}/api/evidence?caseId=${encodeURIComponent(caseId)}`),
    ]);
    const investigator = users.find(user => String(user.id) === String(caseData.investigator_id));
    return { ...caseData, investigator_name: investigator?.username || null, evidence };
  }

  async createCase({ title, investigatorId, caseNumber }) {
    if (!title || !title.trim()) throw new Error('Case title is required');
    return caseRepository.createCase({ caseNumber: caseNumber || `CASE-${Date.now()}`, title: title.trim(), investigatorId: investigatorId || null });
  }
}

module.exports = new CaseService();