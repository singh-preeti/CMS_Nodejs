const express = require('express');
const userService = require('../services/userService');

const router = express.Router();
router.get('/', (req, res) => res.redirect('/users'));
router.get('/users', async (req, res) => {
  try { res.render('users', { title: 'Users', page: 'users', users: await userService.getAllUsers(), error: null, values: {} }); }
  catch (error) { res.status(500).send(error.message); }
});
router.post('/users', async (req, res) => {
  try { await userService.createUser(req.body || {}); res.redirect('/users'); }
  catch (error) { res.status(400).render('users', { title: 'Users', page: 'users', users: await userService.getAllUsers(), error: error.message, values: req.body || {} }); }
});

module.exports = router;