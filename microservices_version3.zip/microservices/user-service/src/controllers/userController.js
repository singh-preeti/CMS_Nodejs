const userService = require('../services/userService');

class UserController {
  async getAllUsers(req, res, next) {
    try { res.json(await userService.getAllUsers()); } catch (error) { next(error); }
  }

  async createUser(req, res, next) {
    try { res.status(201).json(await userService.createUser(req.body || {})); }
    catch (error) { res.status(error.code === '23505' ? 409 : 400).json({ error: error.code === '23505' ? 'Username already exists' : error.message }); }
  }
}

module.exports = new UserController();