const userRepository = require('../repositories/userRepository');

class UserService {
  async getAllUsers() {
    return userRepository.getAllUsers();
  }

  async createUser({ username, password, role }) {
    if (!username || !username.trim()) throw new Error('Username is required');
    if (!password || !password.trim()) throw new Error('Password is required');
    return userRepository.createUser({ username: username.trim(), password: password.trim(), role: role?.trim() || 'investigator' });
  }
}

module.exports = new UserService();