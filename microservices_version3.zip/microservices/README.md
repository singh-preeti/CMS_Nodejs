# Evidence Management Microservices

This version demonstrates four independently deployable Node.js services.
There is no API gateway and no Docker. Each service owns its UI, API, process,
and PostgreSQL database.

Ports:

- `user-service` and Users UI - port `3000`
- `case-service` and Cases UI - port `3001`
- `evidence-service` and Evidence UI - port `3002`
- `criminal-service` and Criminals UI - port `3003`

Each backend owns a separate PostgreSQL database: `case_db`, `evidence_db`,
`user_db`, and `criminal_db`. The database schemas are in each service's
`db/schema.sql` folder.
Each service has EJS views in its own `views` folder and shared styling in its
own `public/styles.css` file.

Each service follows the same layered structure:

```text
service/
├── server.js              # middleware, health check, route registration
├── src/config             # PostgreSQL connection pool
├── src/routes             # API routes and EJS page routes
├── src/controllers        # HTTP request/response handling
├── src/services           # validation, business logic, service-to-service calls
└── src/repositories       # SQL queries for that service's database
```

The User service has a user repository/service/controller. The Case service has
case layers and calls User and Evidence through HTTP. The Evidence service has
evidence and custody repositories/services/controllers and calls Case and User
through HTTP. This keeps database access out of controllers and keeps
`server.js` small.

The Criminal service has criminal repositories/services/controllers and calls
Case service for related case information and User service for record creators.

See [SERVICE-COMMUNICATION.md](SERVICE-COMMUNICATION.md) for the detailed
communication flows and request examples.

Service communication is direct HTTP:

- Case service calls User service to load investigators.
- Case service calls Evidence service to load evidence for a case.
- Evidence service calls Case service for case information and User service for upload users.
- Criminal service calls Case service for related cases and User service for record creators.
- Each page links directly to the other service's port so the distributed design is visible.

## Run locally without Docker

Prerequisites: Node.js 18+, PostgreSQL, and the PostgreSQL command-line tools
(`createdb` and `psql`) available in PowerShell.

Create the databases and apply each service's schema:

```powershell
createdb -U postgres case_db
createdb -U postgres evidence_db
createdb -U postgres user_db
createdb -U postgres criminal_db

psql -U postgres -d case_db -f .\case-service\db\schema.sql
psql -U postgres -d evidence_db -f .\evidence-service\db\schema.sql
psql -U postgres -d user_db -f .\user-service\db\schema.sql
psql -U postgres -d criminal_db -f .\criminal-service\db\schema.sql
```

If a database already exists, skip its `createdb` command. PostgreSQL will ask
for the password of the `postgres` user.

Start each service in a separate PowerShell terminal:

```powershell
# Terminal 1: User service and Users UI
cd user-service
$env:DB_NAME = 'user_db'
$env:PORT = '3000'
npm install
npm start

# Terminal 4: Criminal service and Criminals UI
cd criminal-service
$env:DB_NAME = 'criminal_db'
$env:PORT = '3003'
npm install
npm start

# Terminal 2: Case service and Cases UI
cd case-service
$env:DB_NAME = 'case_db'
$env:PORT = '3001'
npm install
npm start

# Terminal 3: Evidence service and Evidence UI
cd evidence-service
$env:DB_NAME = 'evidence_db'
$env:PORT = '3002'
npm install
npm start
```

Then open these pages:

- `http://localhost:3000/users`
- `http://localhost:3001/cases`
- `http://localhost:3002/evidence`
- `http://localhost:3003/criminals`

The EJS UIs provide screens for creating users and cases, uploading evidence,
viewing case/evidence details, and recording custody transfers.
The Criminals UI adds criminal records linked to cases and users.

For separate servers, configure the direct service URLs for example:

```env
USER_SERVICE_URL=http://10.0.0.11:3000
CASE_SERVICE_URL=http://10.0.0.12:3001
EVIDENCE_SERVICE_URL=http://10.0.0.13:3002
CRIMINAL_SERVICE_URL=http://10.0.0.14:3003
```