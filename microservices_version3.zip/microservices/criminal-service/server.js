require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const pool = require('./src/config/database');
const apiRoutes = require('./src/routes/api');
const viewRoutes = require('./src/routes/views');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.locals.serviceLinks = {
  users: process.env.USER_SERVICE_PUBLIC_URL || 'http://localhost:3000',
  cases: process.env.CASE_SERVICE_PUBLIC_URL || 'http://localhost:3001',
  evidence: process.env.EVIDENCE_SERVICE_PUBLIC_URL || 'http://localhost:3002',
  criminals: process.env.CRIMINAL_SERVICE_PUBLIC_URL || 'http://localhost:3003',
};
app.get('/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ service: 'criminal-service', status: 'running', port: 3003, communicatesWith: ['user-service', 'case-service'] }); }
  catch (error) { res.status(503).json({ service: 'criminal-service', status: 'unavailable', error: error.message }); }
});
app.use('/api', apiRoutes);
app.use(viewRoutes);
app.use((error, req, res, next) => { console.error(error); res.status(500).json({ error: 'Criminal service request failed' }); });

const port = process.env.PORT || 3003;
app.listen(port, () => console.log(`Criminal service listening on ${port}`));
