const criminalService = require('../services/criminalService');

class CriminalController {
  async list(req, res, next) { try { res.json(await criminalService.getAllCriminals()); } catch (error) { next(error); } }
  async getById(req, res, next) {
    try { res.json(await criminalService.getCriminalById(req.params.id)); }
    catch (error) { res.status(error.message === 'Criminal not found' ? 404 : 502).json({ error: error.message }); }
  }
  async create(req, res, next) {
    try { res.status(201).json(await criminalService.createCriminal(req.body || {})); }
    catch (error) { res.status(400).json({ error: error.message }); }
  }
}

module.exports = new CriminalController();