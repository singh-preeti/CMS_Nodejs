const criminalService = require('../services/criminalService');

class CriminalViewController {
  async list(req, res) {
    try { res.render('criminals', { title: 'Criminals', page: 'criminals', criminals: await criminalService.getAllCriminals(), error: null }); }
    catch (error) { res.status(502).send(error.message); }
  }

  async newForm(req, res) {
    try {
      const { cases, users } = await criminalService.getFormOptions();
      res.render('criminal-form', { title: 'Add Criminal', page: 'criminals', cases, users, error: null, values: {} });
    } catch (error) { res.status(502).send(error.message); }
  }

  async create(req, res) {
    try { await criminalService.createCriminal(req.body || {}); res.redirect('/criminals'); }
    catch (error) {
      const { cases, users } = await criminalService.getFormOptions();
      res.status(400).render('criminal-form', { title: 'Add Criminal', page: 'criminals', cases, users, error: error.message, values: req.body || {} });
    }
  }

  async details(req, res) {
    try { res.render('criminal-details', { title: 'Criminal Details', page: 'criminals', criminal: await criminalService.getCriminalById(req.params.id) }); }
    catch (error) { res.status(404).send(error.message); }
  }
}

module.exports = new CriminalViewController();