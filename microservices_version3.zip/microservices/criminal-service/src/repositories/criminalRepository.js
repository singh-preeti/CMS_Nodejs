const pool = require('../config/database');

class CriminalRepository {
  async getAll() {
    return (await pool.query('SELECT * FROM criminals ORDER BY created_at DESC')).rows;
  }

  async getById(id) {
    return (await pool.query('SELECT * FROM criminals WHERE id = $1', [id])).rows[0] || null;
  }

  async create(criminal) {
    return (await pool.query(
      `INSERT INTO criminals (full_name, alias, date_of_birth, crime_type, status, case_id, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [criminal.fullName, criminal.alias || null, criminal.dateOfBirth || null, criminal.crimeType, criminal.status, criminal.caseId || null, criminal.createdBy || null],
    )).rows[0];
  }
}

module.exports = new CriminalRepository();