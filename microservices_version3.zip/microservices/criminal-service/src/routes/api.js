const express = require('express');
const criminalController = require('../controllers/criminalController');

const router = express.Router();
router.get('/criminals', criminalController.list);
router.get('/criminals/:id', criminalController.getById);
router.post('/criminals', criminalController.create);

module.exports = router;