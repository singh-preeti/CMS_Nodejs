const criminalRepository = require('../repositories/criminalRepository');

const caseServiceUrl = process.env.CASE_SERVICE_URL || 'http://localhost:3001';
const userServiceUrl = process.env.USER_SERVICE_URL || 'http://localhost:3000';

async function requestJson(url) {
  const response = await fetch(url);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Connected service request failed');
  return data;
}

class CriminalService {
  async getAllCriminals() {
    const [criminals, cases] = await Promise.all([criminalRepository.getAll(), requestJson(`${caseServiceUrl}/api/cases`)]);
    const caseNumbers = new Map(cases.map(item => [String(item.id), item.case_number]));
    return criminals.map(item => ({ ...item, case_number: caseNumbers.get(String(item.case_id)) || null }));
  }

  async getCriminalById(id) {
    const criminal = await criminalRepository.getById(id);
    if (!criminal) throw new Error('Criminal not found');
    const caseData = criminal.case_id ? await requestJson(`${caseServiceUrl}/api/cases/${criminal.case_id}`) : null;
    return { ...criminal, case_number: caseData?.case_number || null, case_title: caseData?.title || null };
  }

  async getFormOptions() {
    return Promise.all([
      requestJson(`${caseServiceUrl}/api/cases`),
      requestJson(`${userServiceUrl}/api/users`),
    ]).then(([cases, users]) => ({ cases, users }));
  }

  async createCriminal({ fullName, alias, dateOfBirth, crimeType, status, caseId, createdBy }) {
    if (!fullName?.trim()) throw new Error('Full name is required');
    if (!crimeType?.trim()) throw new Error('Crime type is required');
    return criminalRepository.create({
      fullName: fullName.trim(), alias: alias?.trim(), dateOfBirth, crimeType: crimeType.trim(),
      status: status || 'wanted', caseId: Number(caseId) || null, createdBy: Number(createdBy) || null,
    });
  }
}

module.exports = new CriminalService();