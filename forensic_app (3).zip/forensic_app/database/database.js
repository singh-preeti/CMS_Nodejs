require("dotenv").config();

const { Pool } = require("pg");
const bcrypt = require("bcrypt");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

async function initializeDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      user_id SERIAL PRIMARY KEY,
      username VARCHAR(255) UNIQUE NOT NULL,
      password VARCHAR(255) NOT NULL,
      role VARCHAR(100) NOT NULL DEFAULT 'investigator',
      department VARCHAR(255) NOT NULL DEFAULT 'Forensics'
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS cases (
      case_id VARCHAR(255) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      status VARCHAR(100) NOT NULL DEFAULT 'Open',
      assigned_investigator INTEGER REFERENCES users(user_id),
      created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS evidence (
      evidence_id SERIAL PRIMARY KEY,
      case_id VARCHAR(255) NOT NULL REFERENCES cases(case_id),
      type VARCHAR(255) NOT NULL,
      file_path TEXT,
      hash VARCHAR(255),
      upload_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      status VARCHAR(100) NOT NULL DEFAULT 'Pending'
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS custody (
      custody_id SERIAL PRIMARY KEY,
      evidence_id INTEGER NOT NULL REFERENCES evidence(evidence_id),
      action VARCHAR(255) NOT NULL,
      from_officer VARCHAR(255),
      to_officer VARCHAR(255),
      timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS audit_log (
      audit_id SERIAL PRIMARY KEY,
      action VARCHAR(255) NOT NULL,
      user_id INTEGER REFERENCES users(user_id),
      entity_type VARCHAR(100),
      entity_id VARCHAR(255),
      timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await migrateLegacyColumns();
  await pool.query("CREATE INDEX IF NOT EXISTS evidence_type_idx ON evidence(type)");
  await pool.query("CREATE INDEX IF NOT EXISTS evidence_status_idx ON evidence(status)");
  await pool.query("CREATE INDEX IF NOT EXISTS evidence_upload_date_idx ON evidence(upload_date)");
  await pool.query("CREATE INDEX IF NOT EXISTS cases_investigator_idx ON cases(assigned_investigator)");
  await pool.query("CREATE INDEX IF NOT EXISTS audit_timestamp_idx ON audit_log(timestamp)");

  const { rows } = await pool.query("SELECT COUNT(*) AS total FROM users");
  if (Number(rows[0].total) === 0) {
    const passwordHash = await bcrypt.hash("admin123", 12);
    await pool.query(
      "INSERT INTO users (username, password, role, department) VALUES ($1, $2, $3, $4)",
      ["investigator", passwordHash, "investigator", "Forensics"]
    );
    console.log("Default investigator user created: investigator / admin123");
  }
}

async function migrateLegacyColumns() {
  const operations = [
    ["users", "id", "user_id"],
    ["cases", "id", "legacy_id"],
    ["cases", "investigator", "legacy_investigator"],
    ["cases", "created_at", "created_date"],
    ["evidence", "id", "evidence_id"],
    ["evidence", "created_at", "upload_date"],
    ["custody", "id", "custody_id"],
    ["custody", "performed_by", "to_officer"],
    ["custody", "created_at", "timestamp"],
    ["audit_log", "id", "audit_id"],
    ["audit_log", "created_at", "timestamp"],
  ];

  for (const [table, oldColumn, newColumn] of operations) {
    await pool.query(`
      DO $$ BEGIN
        IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = '${table}' AND column_name = '${oldColumn}')
          AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = '${table}' AND column_name = '${newColumn}') THEN
          ALTER TABLE ${table} RENAME COLUMN ${oldColumn} TO ${newColumn};
        END IF;
      END $$;
    `);
  }

  await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(100) NOT NULL DEFAULT 'investigator'");
  await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS department VARCHAR(255) NOT NULL DEFAULT 'Forensics'");
  await pool.query("ALTER TABLE cases ADD COLUMN IF NOT EXISTS assigned_investigator INTEGER REFERENCES users(user_id)");
  await pool.query("ALTER TABLE cases ADD COLUMN IF NOT EXISTS created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
  await pool.query("ALTER TABLE evidence ADD COLUMN IF NOT EXISTS file_path TEXT");
  await pool.query("ALTER TABLE evidence ADD COLUMN IF NOT EXISTS hash VARCHAR(255)");
  await pool.query("ALTER TABLE evidence ADD COLUMN IF NOT EXISTS upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
  await pool.query("ALTER TABLE custody ADD COLUMN IF NOT EXISTS from_officer VARCHAR(255)");
  await pool.query("ALTER TABLE custody ADD COLUMN IF NOT EXISTS to_officer VARCHAR(255)");
  await pool.query("ALTER TABLE custody ADD COLUMN IF NOT EXISTS timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
  await pool.query("ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS entity_type VARCHAR(100)");
  await pool.query("ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS entity_id VARCHAR(255)");
  await pool.query("ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
}

async function recordAudit(userId, action, entityType, entityId) {
  await pool.query(
    "INSERT INTO audit_log (user_id, action, entity_type, entity_id) VALUES ($1, $2, $3, $4)",
    [userId, action, entityType, String(entityId)]
  );
}

module.exports = { pool, initializeDatabase, recordAudit };
