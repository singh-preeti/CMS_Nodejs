require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const pool = require('./src/config/database');
const apiRoutes = require('./src/routes/api');
const viewRoutes = require('./src/routes/views');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.locals.serviceLinks = {
  users: process.env.USER_SERVICE_PUBLIC_URL || 'http://localhost:3000',
  cases: process.env.CASE_SERVICE_PUBLIC_URL || 'http://localhost:3001',
  evidence: process.env.EVIDENCE_SERVICE_PUBLIC_URL || 'http://localhost:3002',
};
app.get('/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ service: 'evidence-service', status: 'running', port: 3002, communicatesWith: ['user-service', 'case-service'] }); }
  catch (error) { res.status(503).json({ service: 'evidence-service', status: 'unavailable', error: error.message }); }
});
app.use('/api', apiRoutes);
app.use(viewRoutes);
app.use((error, req, res, next) => {
  console.error(error);
  res.status(error.message === 'Duplicate evidence hash detected' ? 400 : 500).json({ error: error.message || 'Evidence service request failed' });
});

const port = process.env.PORT || 3002;
app.listen(port, () => console.log(`Evidence service listening on ${port}`));
