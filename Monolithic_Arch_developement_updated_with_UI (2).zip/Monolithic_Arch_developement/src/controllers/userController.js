const userService = require('../services/userService');

class UserController {
  async getAllUsers(req, res) {
    try {
      const users = await userService.getAllUsers();
      return res.status(200).json(users);
    } catch (error) {
      return res.status(500).json({ error: error.message || 'Failed to fetch users' });
    }
  }

  async createUser(req, res) {
    try {
      const user = await userService.createUser(req.body || {});
      return res.status(201).json(user);
    } catch (error) {
      const status = error.code === '23505' ? 409 : 400;
      return res.status(status).json({ error: error.code === '23505' ? 'Username already exists' : error.message });
    }
  }
}

module.exports = new UserController();