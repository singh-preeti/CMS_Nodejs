const pool = require('../config/database');

class UserRepository {
  async getAllUsers() {
    const result = await pool.query(
      `SELECT id, username, role, created_at
       FROM users
       ORDER BY username ASC`
    );

    return result.rows;
  }

  async createUser({ username, password, role }) {
    const result = await pool.query(
      `INSERT INTO users (username, password, role)
       VALUES ($1, $2, $3)
       RETURNING id, username, role, created_at`,
      [username, password, role || 'investigator']
    );

    return result.rows[0];
  }
}

module.exports = new UserRepository();