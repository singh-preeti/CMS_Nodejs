const express = require('express');
const multer = require('multer');

const caseController = require('../controllers/caseController');
const evidenceController = require('../controllers/evidenceController');
const userController = require('../controllers/userController');

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024 * 1024,
  },
});

router.get('/api/users', userController.getAllUsers);
router.post('/api/users', userController.createUser);

router.get('/api/cases', caseController.getAllCases);
router.get('/api/cases/:id', caseController.getCaseById);
router.post('/api/cases', caseController.createCase);

router.get('/api/evidence/:id', evidenceController.getEvidenceById);
router.post('/api/evidence/upload', upload.single('file'), evidenceController.uploadEvidence);
router.get('/api/evidence/:id/custody', evidenceController.getCustodyHistory);
router.post('/api/evidence/:id/transfer', evidenceController.transferEvidence);
router.post('/api/evidence/:id/verify', evidenceController.verifyIntegrity);

module.exports = router;
