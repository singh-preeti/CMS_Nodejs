const express = require('express');
const multer = require('multer');

const caseService = require('../services/caseService');
const evidenceService = require('../services/evidenceService');
const userService = require('../services/userService');

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 * 1024 },
});

function renderError(res, view, data, error) {
  return res.status(400).render(view, { ...data, error: error.message || 'Request failed' });
}

router.get('/dashboard', async (req, res) => {
  try {
    const [cases, users] = await Promise.all([caseService.getAllCases(), userService.getAllUsers()]);
    return res.render('dashboard', { title: 'Dashboard', page: 'dashboard', cases, users });
  } catch (error) {
    return res.status(500).send(error.message);
  }
});

router.get('/users', async (req, res) => {
  try {
    const users = await userService.getAllUsers();
    return res.render('users', { title: 'Users', page: 'users', users, error: null, values: {} });
  } catch (error) {
    return res.status(500).send(error.message);
  }
});

router.post('/users', async (req, res) => {
  try {
    await userService.createUser(req.body || {});
    return res.redirect('/users');
  } catch (error) {
    const users = await userService.getAllUsers();
    return renderError(res, 'users', { title: 'Users', page: 'users', users, values: req.body || {} }, error);
  }
});

router.get('/cases', async (req, res) => {
  try {
    const [cases, users] = await Promise.all([caseService.getAllCases(), userService.getAllUsers()]);
    return res.render('cases', { title: 'Cases', page: 'cases', cases, users, error: null, values: {} });
  } catch (error) {
    return res.status(500).send(error.message);
  }
});

router.post('/cases', async (req, res) => {
  try {
    await caseService.createCase({
      title: req.body.title,
      caseNumber: req.body.caseNumber,
      investigatorId: Number(req.body.investigatorId),
    });
    return res.redirect('/cases');
  } catch (error) {
    const [cases, users] = await Promise.all([caseService.getAllCases(), userService.getAllUsers()]);
    return renderError(res, 'cases', { title: 'Cases', page: 'cases', cases, users, values: req.body || {} }, error);
  }
});

router.get('/cases/:id', async (req, res) => {
  try {
    const caseData = await caseService.getCaseById(req.params.id);
    return res.render('case-details', { title: caseData.case_number, page: 'cases', caseData });
  } catch (error) {
    return res.status(404).send(error.message);
  }
});

router.get('/evidence', async (req, res) => {
  try {
    const cases = await caseService.getAllCases();
    const evidence = (await Promise.all(cases.map(item => caseService.getCaseById(item.id)))).flatMap(item => item.evidence || []);
    return res.render('evidence', { title: 'Evidence', page: 'evidence', evidence, error: null });
  } catch (error) {
    return res.status(500).send(error.message);
  }
});

router.get('/evidence/new', async (req, res) => {
  const [cases, users] = await Promise.all([caseService.getAllCases(), userService.getAllUsers()]);
  return res.render('evidence-form', { title: 'Upload Evidence', page: 'evidence', cases, users, error: null, values: {} });
});

router.post('/evidence/new', upload.single('file'), async (req, res) => {
  try {
    await evidenceService.uploadEvidence(req.file, Number(req.body.caseId), req.body.type, Number(req.body.uploadedBy));
    return res.redirect('/evidence');
  } catch (error) {
    const [cases, users] = await Promise.all([caseService.getAllCases(), userService.getAllUsers()]);
    return renderError(res, 'evidence-form', { title: 'Upload Evidence', page: 'evidence', cases, users, values: req.body || {} }, error);
  }
});

router.get('/evidence/:id', async (req, res) => {
  try {
    const [evidence, custody] = await Promise.all([
      evidenceService.getEvidenceById(req.params.id),
      evidenceService.getEvidenceCustodyHistory(req.params.id),
    ]);
    return res.render('evidence-details', { title: evidence.evidence_number, page: 'evidence', evidence, custody, error: null });
  } catch (error) {
    return res.status(404).send(error.message);
  }
});

router.post('/evidence/:id/transfer', async (req, res) => {
  try {
    await evidenceService.transferEvidence(req.params.id, {
      fromUser: Number(req.body.fromUser),
      toUser: Number(req.body.toUser),
      reason: req.body.reason,
    });
    return res.redirect(`/evidence/${req.params.id}`);
  } catch (error) {
    return res.status(400).send(error.message);
  }
});

module.exports = router;