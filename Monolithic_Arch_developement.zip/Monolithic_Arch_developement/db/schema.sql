CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'investigator',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cases (
  id SERIAL PRIMARY KEY,
  case_number VARCHAR(50) UNIQUE NOT NULL,
  title VARCHAR(255) NOT NULL,
  status VARCHAR(50) DEFAULT 'open',
  investigator_id INTEGER REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS evidence (
  id SERIAL PRIMARY KEY,
  evidence_number VARCHAR(50) UNIQUE NOT NULL,
  case_id INTEGER REFERENCES cases(id) ON DELETE CASCADE,
  file_name VARCHAR(255) NOT NULL,
  stored_path VARCHAR(500) NOT NULL,
  file_type VARCHAR(100),
  file_size BIGINT,
  sha256 VARCHAR(128),
  status VARCHAR(50) DEFAULT 'uploaded',
  uploaded_by INTEGER REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS custody_entries (
  id SERIAL PRIMARY KEY,
  evidence_id INTEGER REFERENCES evidence(id) ON DELETE CASCADE,
  from_user INTEGER REFERENCES users(id),
  to_user INTEGER REFERENCES users(id),
  movement_type VARCHAR(50) NOT NULL,
  reason TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (username, password, role)
VALUES ('postgres', 'mysql', 'investigator')
ON CONFLICT (username) DO NOTHING;

INSERT INTO cases (case_number, title, status, investigator_id)
VALUES ('CASE-001', 'Evidence intake for suspicious activity', 'open', 1)
ON CONFLICT (case_number) DO NOTHING;
