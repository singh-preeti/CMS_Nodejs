require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const routes = require('./src/routes');
const pool = require('./src/config/database');

const app = express();
const PORT = process.env.PORT || 3000;

const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

app.use(cors());
app.use(express.json({ limit: '10GB' }));
app.use(express.urlencoded({ extended: true }));
app.use(routes);

app.get('/', (req, res) => {
  res.json({
    app: 'Evidence Management API',
    status: 'running',
    version: '1.0.0',
    database: process.env.DB_NAME || 'evidence_db',
  });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal Server Error' });
});

async function startServer() {
  try {
    await pool.query('SELECT 1');
    console.log('PostgreSQL connection successful');
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to connect to PostgreSQL:', error.message);
    console.log('Please ensure PostgreSQL is running and configured with:');
    console.log('username: postgres');
    console.log('password: mysql');
    process.exit(1);
  }
}

startServer();
