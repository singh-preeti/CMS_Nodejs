# Evidence Management API

A monolithic Node.js backend for evidence management built with Express and PostgreSQL.

## Features
- Case management APIs
- Evidence upload with SHA-256 hashing
- Custody transfer tracking
- Integrity verification support
- PostgreSQL database connection pooling
- Layered architecture with controllers, services, repositories, and routes

## Prerequisites
- Node.js 18+
- PostgreSQL server running locally
- A database named `evidence_db`

## Setup
1. Copy `.env.example` to `.env`.
2. Update PostgreSQL credentials if needed.
3. Create the database and run the schema:
   ```bash
   createdb evidence_db
   psql -U postgres -d evidence_db -f db/schema.sql
   ```
4. Install dependencies:
   ```bash
   npm install
   ```
5. Start the server:
   ```bash
   npm start
   ```

## Default DB credentials
- Username: `postgres`
- Password: `mysql`

## API endpoints
- `GET /api/cases`
- `GET /api/cases/:id`
- `POST /api/cases`
- `GET /api/evidence/:id`
- `POST /api/evidence/upload`
- `GET /api/evidence/:id/custody`
- `POST /api/evidence/:id/transfer`

## Example request
```bash
curl http://localhost:3000/api/cases
```

## Notes
- Real files are stored under the `uploads/` directory.
- Uploaded files are hashed using SHA-256 before storing metadata in PostgreSQL.
- Authentication has been removed to keep the app simple and easy to use.
