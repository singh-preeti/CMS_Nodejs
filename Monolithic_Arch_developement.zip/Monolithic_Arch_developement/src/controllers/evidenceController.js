const evidenceService = require('../services/evidenceService');
const integrityService = require('../services/integrityService');

class EvidenceController {
  async getEvidenceById(req, res) {
    try {
      const evidence = await evidenceService.getEvidenceById(req.params.id);
      return res.status(200).json(evidence);
    } catch (error) {
      const status = error.message === 'Evidence not found' ? 404 : 500;
      return res.status(status).json({ error: error.message || 'Failed to fetch evidence' });
    }
  }

  async uploadEvidence(req, res) {
    try {
      const file = req.file;
      const rawCaseId = req.body?.caseId ?? req.body?.case_id;
      const rawType = req.body?.type;
      const rawUploadedBy = req.body?.uploadedBy ?? req.body?.uploaded_by ?? 1;

      if (!file) {
        return res.status(400).json({ error: 'File is required' });
      }

      const numericUploadedBy = Number(rawUploadedBy);
      const result = await evidenceService.uploadEvidence(
        file,
        rawCaseId,
        rawType,
        Number.isFinite(numericUploadedBy) ? numericUploadedBy : 1
      );

      return res.status(201).json(result);
    } catch (error) {
      const status = error.message === 'File exceeds 10GB limit' || error.message === 'Duplicate evidence hash detected' ? 400 : 500;
      return res.status(status).json({ error: error.message || 'Upload failed' });
    }
  }

  async getCustodyHistory(req, res) {
    try {
      const history = await evidenceService.getEvidenceCustodyHistory(req.params.id);
      return res.status(200).json(history);
    } catch (error) {
      return res.status(500).json({ error: error.message || 'Failed to fetch custody history' });
    }
  }

  async transferEvidence(req, res) {
    try {
      const result = await evidenceService.transferEvidence(req.params.id, req.body || {});
      return res.status(200).json(result);
    } catch (error) {
      return res.status(400).json({ error: error.message || 'Transfer failed' });
    }
  }

  async verifyIntegrity(req, res) {
    try {
      const result = await integrityService.verifyEvidenceHash(req.params.id, req.body?.hash);
      return res.status(200).json(result);
    } catch (error) {
      return res.status(404).json({ error: error.message || 'Verification failed' });
    }
  }
}

module.exports = new EvidenceController();
