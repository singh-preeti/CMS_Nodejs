const caseService = require('../services/caseService');

class CaseController {
  async getAllCases(req, res) {
    try {
      const cases = await caseService.getAllCases();
      return res.status(200).json(cases);
    } catch (error) {
      return res.status(500).json({ error: error.message || 'Failed to fetch cases' });
    }
  }

  async getCaseById(req, res) {
    try {
      const caseData = await caseService.getCaseById(req.params.id);
      return res.status(200).json(caseData);
    } catch (error) {
      const status = error.message === 'Case not found' ? 404 : 500;
      return res.status(status).json({ error: error.message || 'Failed to fetch case' });
    }
  }

  async createCase(req, res) {
    try {
      const { title, investigatorId, caseNumber } = req.body || {};

      const newCase = await caseService.createCase({ title, investigatorId, caseNumber });
      return res.status(201).json(newCase);
    } catch (error) {
      return res.status(400).json({ error: error.message || 'Failed to create case' });
    }
  }
}

module.exports = new CaseController();
