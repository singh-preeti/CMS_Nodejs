const custodyRepository = require('../repositories/custodyRepository');

class CustodyService {
  async createCustodyEntry({ evidenceId, fromUser, toUser, movementType, reason }) {
    return custodyRepository.createCustodyEntry({
      evidenceId,
      fromUser,
      toUser,
      movementType,
      reason,
    });
  }

  async getCustodyHistory(evidenceId) {
    return custodyRepository.getCustodyHistory(evidenceId);
  }

  async transferEvidence(evidenceId, { fromUser, toUser, reason }) {
    const result = await custodyRepository.createCustodyEntry({
      evidenceId,
      fromUser,
      toUser,
      movementType: 'transfer',
      reason: reason || 'Evidence transferred',
    });

    return {
      id: result.id,
      evidenceId,
      fromUser,
      toUser,
      movementType: 'transfer',
      reason: result.reason,
    };
  }
}

module.exports = new CustodyService();
