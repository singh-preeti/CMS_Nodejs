const evidenceRepository = require('../repositories/evidenceRepository');

class IntegrityService {
  async verifyEvidenceHash(evidenceId, providedHash) {
    const evidence = await evidenceRepository.getEvidenceById(evidenceId);

    if (!evidence) {
      throw new Error('Evidence not found');
    }

    const isValid = evidence.sha256 === providedHash;

    if (!isValid) {
      return {
        evidenceId,
        valid: false,
        expectedHash: evidence.sha256,
        providedHash,
        message: 'Hash mismatch detected. Evidence may be tampered with.',
      };
    }

    return {
      evidenceId,
      valid: true,
      expectedHash: evidence.sha256,
      providedHash,
      message: 'Hash matches. Evidence integrity verified.',
    };
  }
}

module.exports = new IntegrityService();
