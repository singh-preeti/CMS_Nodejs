const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const evidenceRepository = require('../repositories/evidenceRepository');
const custodyService = require('./custodyService');

const MAX_FILE_SIZE = 10 * 1024 * 1024 * 1024;

class EvidenceService {
  async uploadEvidence(file, caseId, fileType, uploadedBy) {
    if (!file) {
      throw new Error('File is required');
    }

    if (file.size > MAX_FILE_SIZE) {
      throw new Error('File exceeds 10GB limit');
    }

    if (!caseId) {
      throw new Error('caseId is required');
    }

    if (!fileType || !fileType.trim()) {
      throw new Error('Evidence type is required');
    }

    const uploadDir = path.join(__dirname, '../../uploads');
    fs.mkdirSync(uploadDir, { recursive: true });

    const safeFileName = `${Date.now()}-${file.originalname.replace(/\s+/g, '_')}`;
    const storedPath = path.join(uploadDir, safeFileName);

    const fileBuffer = file.buffer || fs.readFileSync(file.path);

    fs.writeFileSync(storedPath, fileBuffer);

    const sha256 = crypto.createHash('sha256').update(fileBuffer).digest('hex');
    const existingEvidence = await evidenceRepository.findByHash(sha256);

    if (existingEvidence) {
      throw new Error('Duplicate evidence hash detected');
    }

    const evidenceNumber = `EVD-${Date.now()}`;

    const evidenceRecord = await evidenceRepository.createEvidence({
      evidenceNumber,
      caseId,
      fileName: file.originalname,
      storedPath,
      fileType: fileType.trim(),
      fileSize: file.size,
      sha256,
      uploadedBy,
    });

    await custodyService.createCustodyEntry({
      evidenceId: evidenceRecord.id,
      fromUser: uploadedBy,
      toUser: uploadedBy,
      movementType: 'received',
      reason: 'Initial evidence intake',
    });

    return {
      evidenceId: evidenceRecord.id,
      evidenceNumber,
      fileName: evidenceRecord.file_name,
      hash: sha256,
      status: evidenceRecord.status,
    };
  }

  async getEvidenceById(evidenceId) {
    const evidence = await evidenceRepository.getEvidenceById(evidenceId);

    if (!evidence) {
      throw new Error('Evidence not found');
    }

    return evidence;
  }

  async getEvidenceCustodyHistory(evidenceId) {
    return custodyService.getCustodyHistory(evidenceId);
  }

  async transferEvidence(evidenceId, { fromUser, toUser, reason }) {
    if (!fromUser || !toUser) {
      throw new Error('Both sender and recipient are required');
    }

    if (fromUser === toUser) {
      throw new Error('Transfer requires a different recipient');
    }

    return custodyService.transferEvidence(evidenceId, { fromUser, toUser, reason });
  }
}

module.exports = new EvidenceService();
