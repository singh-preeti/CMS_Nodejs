const caseRepository = require('../repositories/caseRepository');
const evidenceRepository = require('../repositories/evidenceRepository');

class CaseService {
  async getAllCases() {
    return caseRepository.getAllCases();
  }

  async getCaseById(caseId) {
    const caseData = await caseRepository.getCaseById(caseId);

    if (!caseData) {
      throw new Error('Case not found');
    }

    const evidence = await evidenceRepository.getEvidenceByCaseId(caseId);
    return {
      ...caseData,
      evidence,
    };
  }

  async createCase({ title, investigatorId, caseNumber }) {
    if (!title || !title.trim()) {
      throw new Error('Case title is required');
    }

    const normalizedCaseNumber = caseNumber || `CASE-${Date.now()}`;

    return caseRepository.createCase({
      caseNumber: normalizedCaseNumber,
      title: title.trim(),
      investigatorId,
    });
  }

  async updateCaseStatus(caseId, status) {
    const existingCase = await caseRepository.getCaseById(caseId);

    if (!existingCase) {
      throw new Error('Case not found');
    }

    return caseRepository.updateCaseStatus(caseId, status);
  }
}

module.exports = new CaseService();
