const pool = require('../config/database');

class CaseRepository {
  async getAllCases() {
    const result = await pool.query(
      `SELECT c.*, u.username AS investigator_name
       FROM cases c
       LEFT JOIN users u ON u.id = c.investigator_id
       ORDER BY c.created_at DESC`
    );

    return result.rows;
  }

  async getCaseById(caseId) {
    const result = await pool.query(
      `SELECT c.*, u.username AS investigator_name
       FROM cases c
       LEFT JOIN users u ON u.id = c.investigator_id
       WHERE c.id = $1`,
      [caseId]
    );

    return result.rows[0] || null;
  }

  async createCase({ caseNumber, title, investigatorId }) {
    const result = await pool.query(
      `INSERT INTO cases (case_number, title, investigator_id)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [caseNumber, title, investigatorId]
    );

    return result.rows[0];
  }

  async updateCaseStatus(caseId, status) {
    const result = await pool.query(
      `UPDATE cases
       SET status = $1
       WHERE id = $2
       RETURNING *`,
      [status, caseId]
    );

    return result.rows[0];
  }
}

module.exports = new CaseRepository();
