const pool = require('../config/database');

class EvidenceRepository {
  async getEvidenceById(evidenceId) {
    const result = await pool.query(
      `SELECT e.*, c.case_number, c.title AS case_title
       FROM evidence e
       JOIN cases c ON c.id = e.case_id
       WHERE e.id = $1`,
      [evidenceId]
    );

    return result.rows[0] || null;
  }

  async getEvidenceByCaseId(caseId) {
    const result = await pool.query(
      `SELECT e.*, c.case_number
       FROM evidence e
       JOIN cases c ON c.id = e.case_id
       WHERE e.case_id = $1
       ORDER BY e.created_at DESC`,
      [caseId]
    );

    return result.rows;
  }

  async createEvidence({ evidenceNumber, caseId, fileName, storedPath, fileType, fileSize, sha256, uploadedBy }) {
    const result = await pool.query(
      `INSERT INTO evidence (evidence_number, case_id, file_name, stored_path, file_type, file_size, sha256, uploaded_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [evidenceNumber, caseId, fileName, storedPath, fileType, fileSize, sha256, uploadedBy]
    );

    return result.rows[0];
  }

  async findByHash(sha256) {
    const result = await pool.query(
      `SELECT * FROM evidence WHERE sha256 = $1 LIMIT 1`,
      [sha256]
    );

    return result.rows[0] || null;
  }

  async updateEvidenceStatus(evidenceId, status) {
    const result = await pool.query(
      `UPDATE evidence
       SET status = $1
       WHERE id = $2
       RETURNING *`,
      [status, evidenceId]
    );

    return result.rows[0];
  }
}

module.exports = new EvidenceRepository();
