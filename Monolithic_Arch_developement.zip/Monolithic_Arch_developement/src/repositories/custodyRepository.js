const pool = require('../config/database');

class CustodyRepository {
  async getCustodyHistory(evidenceId) {
    const result = await pool.query(
      `SELECT ce.*, fu.username AS from_username, tu.username AS to_username
       FROM custody_entries ce
       LEFT JOIN users fu ON fu.id = ce.from_user
       LEFT JOIN users tu ON tu.id = ce.to_user
       WHERE ce.evidence_id = $1
       ORDER BY ce.created_at DESC`,
      [evidenceId]
    );

    return result.rows;
  }

  async createCustodyEntry({ evidenceId, fromUser, toUser, movementType, reason }) {
    const result = await pool.query(
      `INSERT INTO custody_entries (evidence_id, from_user, to_user, movement_type, reason)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [evidenceId, fromUser, toUser, movementType, reason]
    );

    return result.rows[0];
  }
}

module.exports = new CustodyRepository();
