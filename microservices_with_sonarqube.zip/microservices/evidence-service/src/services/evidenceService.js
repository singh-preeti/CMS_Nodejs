const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const evidenceRepository = require("../repositories/evidenceRepository");
const custodyRepository = require("../repositories/custodyRepository");
const { publishEvent } = require("../../../shared/messageBus");
const {
  deleteCacheKeys,
  getCachedJson,
  setCachedJson,
} = require("../../../shared/redis");

const MAX_FILE_SIZE = 10 * 1024 * 1024 * 1024;
const caseServiceUrl = process.env.CASE_SERVICE_URL || "http://localhost:3001";
const userServiceUrl = process.env.USER_SERVICE_URL || "http://localhost:3000";
const uploadDir = path.resolve(
  process.env.UPLOAD_DIR || path.join(__dirname, "../../uploads"),
);
fs.mkdirSync(uploadDir, { recursive: true });

// Call another service and return its JSON response.
async function requestJson(url) {
  const response = await fetch(url);
  const data = await response.json();
  if (!response.ok)
    throw new Error(data.error || "Connected service request failed");
  return data;
}

class EvidenceService {
  // Load evidence and resolve case numbers from Case service.
  async getAllEvidence(caseId) {
    const cacheKey = caseId ? `evidence:list:${caseId}` : "evidence:list";
    const cachedEvidence = await getCachedJson(cacheKey, "evidence-service");
    if (cachedEvidence) return cachedEvidence;

    const [evidence, cases] = await Promise.all([
      evidenceRepository.getAllEvidence(caseId),
      requestJson(`${caseServiceUrl}/api/cases`),
    ]);
    const caseNumbers = new Map(
      cases.map((item) => [String(item.id), item.case_number]),
    );
    const result = evidence.map((item) => ({
      ...item,
      case_number: caseNumbers.get(String(item.case_id)) || item.case_id,
    }));
    await setCachedJson(cacheKey, result, 3600, "evidence-service");
    return result;
  }

  // Load evidence and its related case details.
  async getEvidenceById(evidenceId) {
    const evidence = await evidenceRepository.getEvidenceById(evidenceId);
    if (!evidence) throw new Error("Evidence not found");
    const caseData = await requestJson(
      `${caseServiceUrl}/api/cases/${evidence.case_id}`,
    );
    return {
      ...evidence,
      case_number: caseData.case_number,
      case_title: caseData.title,
    };
  }

  // Load custody history and resolve user names from User service.
  async getCustodyHistory(evidenceId) {
    const [history, users] = await Promise.all([
      custodyRepository.getCustodyHistory(evidenceId),
      requestJson(`${userServiceUrl}/api/users`),
    ]);
    const names = new Map(
      users.map((user) => [String(user.id), user.username]),
    );
    return history.map((entry) => ({
      ...entry,
      from_username: names.get(String(entry.from_user)),
      to_username: names.get(String(entry.to_user)),
    }));
  }

  // Validate, hash, store, and register an uploaded evidence file.
  async uploadEvidence(file, caseId, fileType, uploadedBy) {
    if (!file) throw new Error("File is required");
    if (file.size > MAX_FILE_SIZE) throw new Error("File exceeds 10GB limit");
    if (!caseId) throw new Error("caseId is required");
    if (!fileType || !fileType.trim())
      throw new Error("Evidence type is required");
    const fileBuffer = file.buffer || fs.readFileSync(file.path);
    const sha256 = crypto.createHash("sha256").update(fileBuffer).digest("hex");
    if (await evidenceRepository.findByHash(sha256))
      throw new Error("Duplicate evidence hash detected");
    const storedPath = path.join(
      uploadDir,
      `${Date.now()}-${file.originalname.replace(/\s+/g, "_")}`,
    );
    fs.writeFileSync(storedPath, fileBuffer);
    const record = await evidenceRepository.createEvidence({
      evidenceNumber: `EVD-${Date.now()}`,
      caseId,
      fileName: file.originalname,
      storedPath,
      fileType: fileType.trim(),
      fileSize: file.size,
      sha256,
      uploadedBy,
    });
    await deleteCacheKeys(
      ["evidence:list", `evidence:list:${caseId}`, "cases:list"],
      "evidence-service",
    );
    await custodyRepository.createCustodyEntry({
      evidenceId: record.id,
      fromUser: uploadedBy,
      toUser: uploadedBy,
      movementType: "received",
      reason: "Initial evidence intake",
    });
    await publishEvent("evidence.uploaded", {
      evidenceId: record.id,
      caseId: record.case_id,
      evidenceNumber: record.evidence_number,
    });
    return {
      evidenceId: record.id,
      evidenceNumber: record.evidence_number,
      fileName: record.file_name,
      hash: sha256,
      status: record.status,
    };
  }

  // Validate and record a custody transfer.
  async transferEvidence(evidenceId, { fromUser, toUser, reason }) {
    if (!fromUser || !toUser || fromUser === toUser)
      throw new Error("Transfer requires different sender and recipient");
    const entry = await custodyRepository.createCustodyEntry({
      evidenceId,
      fromUser,
      toUser,
      movementType: "transferred",
      reason,
    });
    await publishEvent("custody.transferred", { evidenceId, fromUser, toUser });
    return entry;
  }

  // Compare a submitted hash with the stored evidence hash.
  async verifyIntegrity(evidenceId, hash) {
    const evidence = await evidenceRepository.getEvidenceById(evidenceId);
    if (!evidence) throw new Error("Evidence not found");
    return { valid: evidence.sha256 === hash, storedHash: evidence.sha256 };
  }
}

module.exports = new EvidenceService();
