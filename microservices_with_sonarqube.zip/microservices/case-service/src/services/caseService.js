const caseRepository = require("../repositories/caseRepository");
const { publishEvent } = require("../../../shared/messageBus");
const {
  deleteCacheKeys,
  getCachedJson,
  setCachedJson,
} = require("../../../shared/redis");

const userServiceUrl = process.env.USER_SERVICE_URL || "http://localhost:3000";
const evidenceServiceUrl =
  process.env.EVIDENCE_SERVICE_URL || "http://localhost:3002";

// Call another service and return its JSON response.
async function requestJson(url) {
  const response = await fetch(url);
  const data = await response.json();
  if (!response.ok)
    throw new Error(data.error || "Connected service request failed");
  return data;
}

class CaseService {
  // Load cases and resolve investigator names from User service.
  async getAllCases() {
    const cachedCases = await getCachedJson("cases:list", "case-service");
    if (cachedCases) return cachedCases;

    const [cases, users] = await Promise.all([
      caseRepository.getAllCases(),
      requestJson(`${userServiceUrl}/api/users`),
    ]);
    const userNames = new Map(
      users.map((user) => [String(user.id), user.username]),
    );
    const result = cases.map((item) => ({
      ...item,
      investigator_name: userNames.get(String(item.investigator_id)) || null,
    }));
    await setCachedJson("cases:list", result, 3600, "case-service");
    return result;
  }

  // Load one case with investigator and evidence information.
  async getCaseById(caseId) {
    const caseData = await caseRepository.getCaseById(caseId);
    if (!caseData) throw new Error("Case not found");
    const [users, evidence] = await Promise.all([
      requestJson(`${userServiceUrl}/api/users`),
      requestJson(
        `${evidenceServiceUrl}/api/evidence?caseId=${encodeURIComponent(caseId)}`,
      ),
    ]);
    const investigator = users.find(
      (user) => String(user.id) === String(caseData.investigator_id),
    );
    return {
      ...caseData,
      investigator_name: investigator?.username || null,
      evidence,
    };
  }

  // Validate and persist a new case.
  async createCase({ title, investigatorId, caseNumber }) {
    if (!title || !title.trim()) throw new Error("Case title is required");
    const newCase = await caseRepository.createCase({
      caseNumber: caseNumber || `CASE-${Date.now()}`,
      title: title.trim(),
      investigatorId: investigatorId || null,
    });
    await deleteCacheKeys(["cases:list"], "case-service");
    await publishEvent("case.created", {
      caseId: newCase.id,
      caseNumber: newCase.case_number,
      title: newCase.title,
    });
    return newCase;
  }
}

module.exports = new CaseService();
