# Redis Architecture Explanation

This document explains how the API Gateway, microservices, PostgreSQL, and Redis work together in this application.

## 1. Important Ports

| Port | Component | Responsibility |
|---:|---|---|
| `4000` | API Gateway | Receives client requests and forwards them to the correct microservice |
| `3000` | User Service | Manages users and user data |
| `3001` | Case Service | Manages investigation cases |
| `3002` | Evidence Service | Manages evidence files, metadata, and custody records |
| `3003` | Criminal Service | Manages criminal records |
| `5432` | PostgreSQL | Stores permanent application data |
| `6379` | Redis | Stores temporary cached data and sessions in memory |

## 2. Redis Does Not Connect to Port 4000

The Redis helper does not connect to the API Gateway.

Redis connects to port `6379` using this configuration:

```javascript
const redisUrl = process.env.REDIS_URL || "redis://localhost:6379";
```

The Redis client is created here:

```javascript
client = createClient({
  url: redisUrl,
  socket: { reconnectStrategy: false },
});
```

The connection is opened here:

```javascript
connectionAttempt = client.connect();
```

These statements are in:

```text
microservices/shared/redis.js
```

## 3. Overall Architecture

```text
Client or Postman
       |
       v
API Gateway :4000
       |
       +---------------------> User Service :3000 -----> user_db
       |
       +---------------------> Case Service :3001 -----> case_db
       |                              |
       |                              +---------------> Redis :6379
       |
       +---------------------> Evidence Service :3002 -> evidence_db
       |                              |
       |                              +---------------> Redis :6379
       |
       +---------------------> Criminal Service :3003 -> criminal_db

All services can use Redis for shared in-memory caching.
```

## 4. Request Flow for Cases

The client sends:

```http
GET http://localhost:4000/api/cases
```

The request flow is:

```text
Client
  |
  v
API Gateway :4000
  |
  v
Case Service :3001
  |
  v
Check Redis key: cases:list
```

### Redis cache hit

If the key exists:

```text
Case Service -> Redis
Redis returns cached cases
Case Service -> API Gateway
API Gateway -> Client
```

PostgreSQL is not queried during a cache hit.

### Redis cache miss

If the key does not exist:

```text
Case Service -> PostgreSQL case_db
PostgreSQL returns case data
Case Service -> Redis
Redis stores the case data
Case Service -> API Gateway
API Gateway -> Client
```

The case data is stored in Redis for one hour.

The cache key is:

```text
cases:list
```

The implementation is in:

```text
microservices/case-service/src/services/caseService.js
```

## 5. Request Flow for Evidence

The client sends:

```http
GET http://localhost:4000/api/evidence
```

The Evidence Service checks Redis first using:

```text
evidence:list
```

If evidence is filtered by case ID, the key is:

```text
evidence:list:<caseId>
```

For example:

```text
evidence:list:1
```

The implementation is in:

```text
microservices/evidence-service/src/services/evidenceService.js
```

## 6. PostgreSQL and Redis Responsibilities

Redis does not replace PostgreSQL.

### PostgreSQL

PostgreSQL is the permanent source of truth. It stores:

- Users
- Cases
- Evidence metadata
- Criminal records
- Custody records

### Redis

Redis is a fast temporary copy of frequently requested data. It stores:

- Cached case lists
- Cached evidence lists
- Filtered evidence lists
- User sessions when Redis-backed sessions are active

The application can recreate the cache from PostgreSQL when the Redis key is
missing or expires.

```text
PostgreSQL = permanent data
Redis = temporary fast cache
Node.js service = controls both systems
```

## 7. Cache Expiration

Case and evidence cache entries use a one-hour TTL:

```javascript
await setCachedJson("cases:list", result, 3600, "case-service");
```

`3600` seconds equals one hour.

Check the remaining time in Redis:

```redis
TTL cases:list
TTL evidence:list
```

Possible results:

```text
Positive number = remaining seconds before expiration
-1 = key exists but has no expiration
-2 = key does not exist
```

## 8. Cache Invalidation

When data changes, the application removes old cache data.

### Creating a case

```text
New case is saved in PostgreSQL
       |
       v
Redis key cases:list is deleted
```

The next request to `GET /api/cases` reads fresh data from PostgreSQL and
creates a new cache entry.

### Uploading evidence

```text
Evidence is saved in PostgreSQL
       |
       +----> evidence:list is deleted
       +----> evidence:list:<caseId> is deleted
       +----> cases:list is deleted
```

The case cache is also cleared because case details can include evidence data.

## 9. Redis Commands for Viewing Data

Open Redis CLI:

```powershell
& "C:\Program Files\Redis\redis-cli.exe"
```

Test the connection:

```redis
PING
```

Expected result:

```text
PONG
```

List all keys:

```redis
SCAN 0
```

View case cache:

```redis
GET cases:list
TTL cases:list
```

View evidence cache:

```redis
GET evidence:list
TTL evidence:list
```

View evidence for case 1:

```redis
GET evidence:list:1
TTL evidence:list:1
```

Search for only case keys:

```redis
SCAN 0 MATCH "cases:*"
```

Search for only evidence keys:

```redis
SCAN 0 MATCH "evidence:*"
```

## 10. Why `SCAN 0` Can Return an Empty List

This output is valid:

```text
1) "0"
2) (empty list or set)
```

It means Redis is working, but no matching key currently exists.

For example, this command only finds case cache keys:

```redis
SCAN 0 MATCH "cases:*"
```

It will not show this key:

```text
redis:manual:test
```

To create application cache data, request the API first:

```http
GET http://localhost:4000/api/cases
GET http://localhost:4000/api/evidence
```

Then run:

```redis
SCAN 0
```

## 11. Redis Sessions

The User Service can use Redis to store sessions. Session keys use this
pattern:

```text
user-session:<session-id>
```

Search for session keys:

```redis
SCAN 0 MATCH "user-session:*"
```

Redis-backed sessions can survive a User Service restart because the session
data is stored outside the Node.js process.

If Redis is unavailable, the application falls back to in-memory sessions for
local development.

## 12. Relevant Code Files

Redis connection and helper functions:

```text
microservices/shared/redis.js
```

Case caching and invalidation:

```text
microservices/case-service/src/services/caseService.js
```

Evidence caching and invalidation:

```text
microservices/evidence-service/src/services/evidenceService.js
```

User Redis session configuration:

```text
microservices/user-service/server.js
```

Redis dependencies:

```text
microservices/shared/package.json
microservices/user-service/package.json
```

Redis user commands:

```text
microservices/REDIS-USER-MANUAL.md
```

## 13. Summary

The API Gateway runs on port `4000`, but Redis does not connect to it directly.

The correct connection relationship is:

```text
Client -> API Gateway :4000 -> Microservice
Microservice -> Redis :6379
Microservice -> PostgreSQL :5432
```

Redis speeds up repeated reads, while PostgreSQL remains the permanent source
of truth. When Redis data is missing or expired, the microservice reads from
PostgreSQL and rebuilds the cache.
