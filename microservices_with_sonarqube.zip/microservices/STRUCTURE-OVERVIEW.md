This project is a beginner-friendly Node.js microservices app built without Docker.
User Service runs on port 3000 and manages user registration, login views, and its own PostgreSQL database.
Case Service runs on port 3001 and handles case records, case details, and case-to-user linking.
Evidence Service runs on port 3002 and stores evidence files, metadata, and custody details in its own database.
Criminal Service runs on port 3003 and manages criminal records and related case information.
Each service owns its own database, so services work independently and communicate through HTTP calls.
API Gateway runs on port 4000 and acts as the single entry point for browser and client requests.
The gateway forwards requests to the correct backend microservice and returns combined responses.
The UI is built with EJS templates, so each service has pages to add and view records in the browser.
User and case data are connected by IDs, while evidence and criminal services can also fetch related data.
Services are designed to run on different servers or machines with separate ports and databases.
Communication is direct HTTP between services, and the gateway is optional for centralized access.
The app is easy to explain to beginners because each service has one responsibility and one database.
This structure makes the project scalable, easier to debug, and closer to real-world microservice architecture.
The entry flow usually starts from the gateway, then routes into the relevant service.
For testing, open the gateway URL and then navigate to each service UI or API endpoint.
This architecture is suitable for learning, demo projects, and small production-style systems.
Redis is an optional shared in-memory data store configured with REDIS_URL.
Case and evidence list responses use a one-hour Redis TTL to reduce repeated database queries.
Creating a case or uploading evidence invalidates the relevant cached lists so responses stay fresh.
The User service stores sessions in Redis when available and falls back to memory when Redis is not running.
