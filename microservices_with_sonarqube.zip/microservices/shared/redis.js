const { createClient } = require("redis");

const redisUrl = process.env.REDIS_URL || "redis://localhost:6379";
let client;
let connectionAttempt;

async function connectRedis(serviceName) {
  if (client?.isReady) return client;
  if (connectionAttempt) return connectionAttempt;

  client = createClient({
    url: redisUrl,
    socket: { reconnectStrategy: false },
  });
  client.on("error", (error) => {
    console.warn(`${serviceName} Redis unavailable: ${error.message}`);
  });
  connectionAttempt = client
    .connect()
    .then(() => {
      console.log(`${serviceName} connected to Redis at ${redisUrl}`);
      return client;
    })
    .catch(() => {
      client = null;
      return null;
    })
    .finally(() => {
      connectionAttempt = null;
    });
  return connectionAttempt;
}

async function getRedisClient(serviceName) {
  return connectRedis(serviceName);
}

async function getCachedJson(key, serviceName) {
  try {
    const redis = await connectRedis(serviceName);
    if (!redis) return null;
    const value = await redis.get(key);
    return value ? JSON.parse(value) : null;
  } catch (error) {
    console.warn(`${serviceName} could not read Redis cache: ${error.message}`);
    return null;
  }
}

async function setCachedJson(key, value, ttlSeconds, serviceName) {
  try {
    const redis = await connectRedis(serviceName);
    if (!redis) return false;
    await redis.set(key, JSON.stringify(value), { EX: ttlSeconds });
    return true;
  } catch (error) {
    console.warn(`${serviceName} could not write Redis cache: ${error.message}`);
    return false;
  }
}

async function deleteCacheKeys(keys, serviceName) {
  try {
    const redis = await connectRedis(serviceName);
    if (!redis || !keys.length) return false;
    await redis.del(keys);
    return true;
  } catch (error) {
    console.warn(`${serviceName} could not invalidate Redis cache: ${error.message}`);
    return false;
  }
}

module.exports = {
  connectRedis,
  getRedisClient,
  getCachedJson,
  setCachedJson,
  deleteCacheKeys,
};