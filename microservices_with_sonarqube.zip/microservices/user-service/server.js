require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const pool = require('./src/config/database');
const apiRoutes = require('./src/routes/api');
const viewRoutes = require('./src/routes/views');
const { connectMessageBus } = require('../shared/messageBus');
const session = require('express-session');
const { RedisStore } = require('connect-redis');
const { getRedisClient } = require('../shared/redis');

const app = express();
const serviceLinks = {
  users: process.env.USER_SERVICE_PUBLIC_URL || 'http://localhost:3000',
  cases: process.env.CASE_SERVICE_PUBLIC_URL || 'http://localhost:3001',
  evidence: process.env.EVIDENCE_SERVICE_PUBLIC_URL || 'http://localhost:3002',
  criminals: process.env.CRIMINAL_SERVICE_PUBLIC_URL || 'http://localhost:3003',
};

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.locals.serviceLinks = serviceLinks;

async function startServer() {
  const redis = await getRedisClient('user-service');
  app.use(session(redis ? {
    store: new RedisStore({ client: redis, prefix: 'user-session:' }),
    secret: process.env.SESSION_SECRET || 'beginner-demo-secret',
    resave: false,
    saveUninitialized: false,
  } : {
    secret: process.env.SESSION_SECRET || 'beginner-demo-secret',
    resave: false,
    saveUninitialized: false,
  }));
  if (!redis) console.warn('User service using in-memory sessions because Redis is unavailable');

  app.use(express.static(path.join(__dirname, 'public')));
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));
  app.get('/health', async (req, res) => {
    try { await pool.query('SELECT 1'); res.json({ service: 'user-service', status: 'running', port: 3000 }); }
    catch (error) { res.status(503).json({ service: 'user-service', status: 'unavailable', error: error.message }); }
  });
  app.get('/api/session', (req, res) => {
    req.session.demoUser = 'redis-session-demo';
    res.json({
      message: 'Session created in Redis',
      sessionId: req.sessionID,
      session: req.session,
    });
  });
  app.delete('/api/session', (req, res) => {
    req.session.destroy((error) => {
      if (error) return res.status(500).json({ error: 'Session could not be deleted' });
      res.json({ message: 'Session deleted' });
    });
  });
  app.use('/api', apiRoutes);
  app.use(viewRoutes);
  // Connect User service to RabbitMQ for publishing domain events.
  connectMessageBus('user-service');
  app.use((error, req, res, next) => { console.error(error); res.status(500).json({ error: 'User service request failed' }); });

  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`User service listening on ${port}`));
}

startServer();
