# Evidence Management Microservices

This version demonstrates four independently deployable Node.js services plus
an optional API gateway and RabbitMQ message broker. Docker is not required.
Each service owns its UI, API, process, and PostgreSQL database.

Ports:

- `user-service` and Users UI - port `3000`
- `case-service` and Cases UI - port `3001`
- `evidence-service` and Evidence UI - port `3002`
- `criminal-service` and Criminals UI - port `3003`
- `api-gateway` and unified API - port `4000`

Each backend owns a separate PostgreSQL database: `case_db`, `evidence_db`,
`user_db`, and `criminal_db`. The database schemas are in each service's
`db/schema.sql` folder.
Each service has EJS views in its own `views` folder and shared styling in its
own `public/styles.css` file.

Each service follows the same layered structure:

```text
service/
├── server.js              # middleware, health check, route registration
├── src/config             # PostgreSQL connection pool
├── src/routes             # API routes and EJS page routes
├── src/controllers        # HTTP request/response handling
├── src/services           # validation, business logic, service-to-service calls
└── src/repositories       # SQL queries for that service's database
```

The User service has a user repository/service/controller. The Case service has
case layers and calls User and Evidence through HTTP. The Evidence service has
evidence and custody repositories/services/controllers and calls Case and User
through HTTP. This keeps database access out of controllers and keeps
`server.js` small.

The Criminal service has criminal repositories/services/controllers and calls
Case service for related case information and User service for record creators.

The optional API gateway does not own business logic or a database. It forwards
client API requests to the correct service and provides one `/health` endpoint.

RabbitMQ is used for asynchronous events. The shared publisher/consumer helper
is in `shared/messageBus.js`. Set `RABBITMQ_URL` when the broker is not on the
local machine; the default is `amqp://localhost:5672`.

Redis is used as an optional shared in-memory data store. Case and evidence
list responses are cached for one hour, and writes invalidate the affected
cache keys. The User service uses Redis for sessions when Redis is available;
it falls back to in-memory sessions so the beginner demo can still start
without Redis. Set `REDIS_URL` to connect to a different Redis server.

See [SERVICE-COMMUNICATION.md](SERVICE-COMMUNICATION.md) for the detailed
communication flows and request examples.
See [API-GATEWAY-GUIDE.md](API-GATEWAY-GUIDE.md) for gateway dependencies,
configuration, routing, uploads, and health checks.

Service communication is direct HTTP:

- Case service calls User service to load investigators.
- Case service calls Evidence service to load evidence for a case.
- Evidence service calls Case service for case information and User service for upload users.
- Criminal service calls Case service for related cases and User service for record creators.
- User publishes `user.created` after a user is stored.
- Case publishes `case.created` after a case is stored.
- Evidence publishes `evidence.uploaded` and `custody.transferred`.
- Case, Evidence, and Criminal consume events relevant to their workflows.
- Each page links directly to the other service's port so the distributed design is visible.

## Run locally without Docker

Prerequisites: Node.js 18+, PostgreSQL, and the PostgreSQL command-line tools
(`createdb` and `psql`) available in PowerShell. RabbitMQ is required for
message events and should be running on `localhost:5672`. Redis is optional;
start it on `localhost:6379` to enable shared caching and Redis sessions.

Create the databases and apply each service's schema:

```powershell
createdb -U postgres case_db
createdb -U postgres evidence_db
createdb -U postgres user_db
createdb -U postgres criminal_db

psql -U postgres -d case_db -f .\case-service\db\schema.sql
psql -U postgres -d evidence_db -f .\evidence-service\db\schema.sql
psql -U postgres -d user_db -f .\user-service\db\schema.sql
psql -U postgres -d criminal_db -f .\criminal-service\db\schema.sql
```

If a database already exists, skip its `createdb` command. PostgreSQL will ask
for the password of the `postgres` user.

Start each service in a separate PowerShell terminal:

```powershell
# Terminal 1: User service and Users UI
cd user-service
$env:DB_NAME = 'user_db'
$env:PORT = '3000'
npm install
npm start

# Optional Terminal 5: API gateway
cd api-gateway
$env:PORT = '4000'
$env:USER_SERVICE_URL = 'http://localhost:3000'
$env:CASE_SERVICE_URL = 'http://localhost:3001'
$env:EVIDENCE_SERVICE_URL = 'http://localhost:3002'
$env:CRIMINAL_SERVICE_URL = 'http://localhost:3003'
npm install
npm start

# Terminal 4: Criminal service and Criminals UI
cd criminal-service
$env:DB_NAME = 'criminal_db'
$env:PORT = '3003'
npm install
npm start

# Terminal 2: Case service and Cases UI
cd case-service
$env:DB_NAME = 'case_db'
$env:PORT = '3001'
npm install
npm start

# Terminal 3: Evidence service and Evidence UI
cd evidence-service
$env:DB_NAME = 'evidence_db'
$env:PORT = '3002'
npm install
npm start
```

Then open these pages:

- `http://localhost:3000/users`
- `http://localhost:3001/cases`
- `http://localhost:3002/evidence`
- `http://localhost:3003/criminals`

## Redis request flow

For `GET /api/cases` or `GET /api/evidence`:

1. The service checks Redis first.
2. A cache hit returns the saved response immediately.
3. A cache miss queries PostgreSQL, stores the response in Redis with a
	one-hour TTL, and returns it.
4. Creating a case clears the case-list cache. Uploading evidence clears the
	evidence-list cache and the case-list cache.

The implementation is in `shared/redis.js`, `case-service/src/services/caseService.js`,
and `evidence-service/src/services/evidenceService.js`.

The EJS UIs provide screens for creating users and cases, uploading evidence,
viewing case/evidence details, and recording custody transfers.
The Criminals UI adds criminal records linked to cases and users.

When the gateway is running, API clients can use:

- `http://localhost:4000/api/users`
- `http://localhost:4000/api/cases`
- `http://localhost:4000/api/evidence`
- `http://localhost:4000/api/criminals`
- `http://localhost:4000/health`

For separate servers, configure the direct service URLs for example:

```env
USER_SERVICE_URL=http://10.0.0.11:3000
CASE_SERVICE_URL=http://10.0.0.12:3001
EVIDENCE_SERVICE_URL=http://10.0.0.13:3002
CRIMINAL_SERVICE_URL=http://10.0.0.14:3003
```
