# Message Queue Guide

## Broker

The services use RabbitMQ through the `amqplib` npm package.

Default connection:

```text
amqp://localhost:5672
```

For another server:

```powershell
$env:RABBITMQ_URL = 'amqp://username:password@10.0.0.20:5672'
```

RabbitMQ must be running before starting the services if you want events to be
published and consumed.

## Shared Message Bus

The common implementation is in `shared/messageBus.js`.

It provides three operations:

- `connectMessageBus(serviceName)` connects a service to RabbitMQ.
- `publishEvent(eventName, payload)` publishes a durable topic event.
- `subscribeToEvent(serviceName, topic, handler)` creates a service queue and
  consumes matching events.

The exchange is named `evidence.events` and uses the `topic` exchange type.
Each service receives its own durable queue, so consumers process events
independently.

## Events

| Event                 | Publisher        | Meaning                       |
| --------------------- | ---------------- | ----------------------------- |
| `user.created`        | User service     | A user was saved in `user_db` |
| `case.created`        | Case service     | A case was saved in `case_db` |
| `evidence.uploaded`   | Evidence service | Evidence was hashed and saved |
| `custody.transferred` | Evidence service | A custody movement was saved  |

## Example Flow

When a new case is created:

1. The Case service validates the request.
2. The Case repository inserts the case into `case_db`.
3. The Case service publishes `case.created`.
4. Evidence service receives the event and can react asynchronously.
5. Criminal service receives the same event and can react asynchronously.

The original HTTP request does not wait for the consumers to finish. This is
the main difference from a direct HTTP call.

## HTTP and Messaging Together

Messaging does not replace every HTTP call.

- Use HTTP when the caller needs an immediate response, such as loading cases
  for an EJS form.
- Use RabbitMQ when a completed action should notify other services, such as a
  newly created case or uploaded evidence.

This combination keeps reads simple and makes event-driven workflows
independent of the publisher.

## Running

Start RabbitMQ, then start the four services and optional gateway as documented
in `README.md`. Each service logs its RabbitMQ connection status. If RabbitMQ
is unavailable, the HTTP service still starts, but published events are skipped
until the service is restarted with a reachable broker.
