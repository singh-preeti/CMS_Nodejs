# API Gateway Guide

## Purpose

The API gateway is an optional public entry point for the four microservices.
It runs on port `4000`, provides a browser-based API console, and forwards API
requests to the service that owns the requested data.

The gateway does not contain business logic and does not connect directly to
PostgreSQL. Each backend service remains responsible for validation, business
logic, and database access.

## Required Dependencies

The gateway is a Node.js Express application.

### Runtime requirements

- Node.js 18 or newer
- The four backend services running and reachable over HTTP
- No Docker requirement
- No PostgreSQL connection required by the gateway

### npm dependencies

The dependencies are defined in `api-gateway/package.json`:

| Package   | Purpose                                                          |
| --------- | ---------------------------------------------------------------- |
| `express` | Creates the HTTP gateway server and routes                       |
| `cors`    | Allows browser applications or other clients to call the gateway |
| `dotenv`  | Loads service URLs and port settings from environment variables  |
| `multer`  | Reads multipart/form-data file uploads before forwarding them    |

Node.js provides the gateway's `fetch`, `FormData`, `Blob`, and HTTP client
functionality. No additional HTTP client package is required.

### Install dependencies

From the `microservices` directory:

```powershell
cd api-gateway
npm install
```

## Service Configuration

The gateway uses these environment variables:

```powershell
$env:PORT = '4000'
$env:USER_SERVICE_URL = 'http://localhost:3000'
$env:CASE_SERVICE_URL = 'http://localhost:3001'
$env:EVIDENCE_SERVICE_URL = 'http://localhost:3002'
$env:CRIMINAL_SERVICE_URL = 'http://localhost:3003'
```

If the variables are not set, the gateway uses the same localhost defaults.
For separate servers, replace the localhost URLs with the private or public
addresses of the servers hosting the services.

Example:

```env
PORT=4000
USER_SERVICE_URL=http://10.0.0.11:3000
CASE_SERVICE_URL=http://10.0.0.12:3001
EVIDENCE_SERVICE_URL=http://10.0.0.13:3002
CRIMINAL_SERVICE_URL=http://10.0.0.14:3003
```

## Starting the Gateway

Start the four services first, then start the gateway in another terminal:

```powershell
cd api-gateway
$env:PORT = '4000'
$env:USER_SERVICE_URL = 'http://localhost:3000'
$env:CASE_SERVICE_URL = 'http://localhost:3001'
$env:EVIDENCE_SERVICE_URL = 'http://localhost:3002'
$env:CRIMINAL_SERVICE_URL = 'http://localhost:3003'
npm start
```

The gateway starts at:

```text
http://localhost:4000
```

Opening the root URL displays the API Console. It lets you select a method,
enter a gateway path such as `/api/users`, submit an optional JSON body, and
view the response directly in the browser.

## How Routing Works

The client sends one request to the gateway. The gateway selects a destination
from the URL and forwards the request to the matching service.

| Gateway route    | Destination service        | Destination route |
| ---------------- | -------------------------- | ----------------- |
| `/api/users`     | User service on `3000`     | `/api/users`      |
| `/api/cases`     | Case service on `3001`     | `/api/cases`      |
| `/api/evidence`  | Evidence service on `3002` | `/api/evidence`   |
| `/api/criminals` | Criminal service on `3003` | `/api/criminals`  |

The gateway forwards the backend's response status, content type, and response
body back to the client.

## User Service Communication

Gateway request:

```text
GET http://localhost:4000/api/users
```

Forwarded request:

```text
GET http://localhost:3000/api/users
```

The User service reads users from `user_db` and returns the response through the
gateway.

Creating a user uses the same pattern:

```text
POST http://localhost:4000/api/users
```

The JSON body is forwarded to the User service.

## Case Service Communication

Gateway request:

```text
GET http://localhost:4000/api/cases
```

Forwarded request:

```text
GET http://localhost:3001/api/cases
```

The Case service reads cases from `case_db`. The Case service can also call the
User and Evidence services directly when it needs investigator or evidence
information. The gateway does not combine those responses itself.

Case details use:

```text
GET http://localhost:4000/api/cases/1
```

The gateway forwards the request to:

```text
GET http://localhost:3001/api/cases/1
```

## Evidence Service Communication

Gateway request:

```text
GET http://localhost:4000/api/evidence
```

Forwarded request:

```text
GET http://localhost:3002/api/evidence
```

Evidence filtering is preserved:

```text
GET http://localhost:4000/api/evidence?caseId=1
```

The gateway forwards the query to:

```text
GET http://localhost:3002/api/evidence?caseId=1
```

Custody and integrity routes are also forwarded:

```text
GET  /api/evidence/1/custody
POST /api/evidence/1/transfer
POST /api/evidence/1/verify
```

### Evidence upload

File uploads use `multipart/form-data`.

Client request:

```text
POST http://localhost:4000/api/evidence/upload
```

The gateway:

1. Reads the uploaded file with `multer`.
2. Creates a new `FormData` object.
3. Adds the file and form fields to the new request.
4. Sends the multipart request to the Evidence service.
5. Returns the Evidence service response to the client.

The destination is:

```text
POST http://localhost:3002/api/evidence/upload
```

The Evidence service calculates the SHA-256 hash, stores the file, writes the
metadata to `evidence_db`, and creates the first custody record.

## Criminal Service Communication

Gateway request:

```text
GET http://localhost:4000/api/criminals
```

Forwarded request:

```text
GET http://localhost:3003/api/criminals
```

The Criminal service reads criminal records from `criminal_db`. It calls the
Case service to resolve case information and the User service when it needs
user information.

Creating a criminal uses:

```text
POST http://localhost:4000/api/criminals
```

The JSON body is forwarded to:

```text
POST http://localhost:3003/api/criminals
```

## Gateway Health Check

The gateway exposes:

```text
GET http://localhost:4000/health
```

The gateway calls `/health` on all four backend services and returns their
availability in one response:

```json
{
  "service": "api-gateway",
  "status": "running",
  "port": 4000,
  "services": {
    "users": "up",
    "cases": "up",
    "evidence": "up",
    "criminals": "up"
  }
}
```

The gateway itself can be running while one backend is unavailable. In that
case, the corresponding service is reported as `down` and requests for that
service return a gateway error.

## Request Flow

```mermaid
flowchart LR
    Client[API client]
    Gateway[API gateway\nPort 4000]
    Users[User service\nPort 3000]
    Cases[Case service\nPort 3001]
    Evidence[Evidence service\nPort 3002]
    Criminals[Criminal service\nPort 3003]

    Client --> Gateway
    Gateway -->|/api/users| Users
    Gateway -->|/api/cases| Cases
    Gateway -->|/api/evidence| Evidence
    Gateway -->|/api/criminals| Criminals
    Cases --> Users
    Cases --> Evidence
    Evidence --> Cases
    Evidence --> Users
    Criminals --> Cases
    Criminals --> Users
```

The important distinction is that the gateway is a traffic director. The
services remain responsible for their own business workflows and direct
service-to-service communication.
