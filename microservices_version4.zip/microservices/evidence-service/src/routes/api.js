const express = require("express");
const multer = require("multer");
const evidenceController = require("../controllers/evidenceController");

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 * 1024 },
});
router.get("/evidence", evidenceController.list);
router.get("/evidence/:id", evidenceController.getById);
router.post(
  "/evidence/upload",
  upload.single("file"),
  evidenceController.upload,
);
router.get("/evidence/:id/custody", evidenceController.custody);
router.post("/evidence/:id/transfer", evidenceController.transfer);
router.post("/evidence/:id/verify", evidenceController.verify);

module.exports = router;
