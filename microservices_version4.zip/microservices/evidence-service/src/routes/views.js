const express = require("express");
const multer = require("multer");
const evidenceViewController = require("../controllers/evidenceViewController");

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 * 1024 },
});
router.get("/", (req, res) => res.redirect("/evidence"));
router.get("/evidence", evidenceViewController.list);
router.get("/evidence/new", evidenceViewController.newForm);
router.post(
  "/evidence/new",
  upload.single("file"),
  evidenceViewController.upload,
);
router.get("/evidence/:id", evidenceViewController.details);
router.post("/evidence/:id/transfer", evidenceViewController.transfer);

module.exports = router;
