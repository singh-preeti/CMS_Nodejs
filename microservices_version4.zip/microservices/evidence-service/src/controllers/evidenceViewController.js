const evidenceService = require("../services/evidenceService");

const caseServiceUrl = process.env.CASE_SERVICE_URL || "http://localhost:3001";
const userServiceUrl = process.env.USER_SERVICE_URL || "http://localhost:3000";

// Load JSON from a connected service for a view.
async function requestJson(url) {
  const response = await fetch(url);
  return response.json();
}

class EvidenceViewController {
  // Render the evidence list page.
  async list(req, res) {
    try {
      res.render("evidence", {
        title: "Evidence",
        page: "evidence",
        evidence: await evidenceService.getAllEvidence(),
        error: null,
      });
    } catch (error) {
      res.status(502).send(error.message);
    }
  }

  // Render the evidence upload form with remote options.
  async newForm(req, res) {
    try {
      const [cases, users] = await Promise.all([
        requestJson(`${caseServiceUrl}/api/cases`),
        requestJson(`${userServiceUrl}/api/users`),
      ]);
      res.render("evidence-form", {
        title: "Upload Evidence",
        page: "evidence",
        cases,
        users,
        error: null,
        values: {},
      });
    } catch (error) {
      res.status(502).send(error.message);
    }
  }

  // Process the server-rendered evidence upload form.
  async upload(req, res) {
    try {
      await evidenceService.uploadEvidence(
        req.file,
        req.body.caseId,
        req.body.type,
        Number(req.body.uploadedBy || 1),
      );
      res.redirect("/evidence");
    } catch (error) {
      res.status(400).send(error.message);
    }
  }

  // Render one evidence record and its custody history.
  async details(req, res) {
    try {
      const evidence = await evidenceService.getEvidenceById(req.params.id);
      const custody = await evidenceService.getCustodyHistory(req.params.id);
      res.render("evidence-details", {
        title: evidence.evidence_number,
        page: "evidence",
        evidence,
        custody,
        error: null,
      });
    } catch (error) {
      res.status(404).send(error.message);
    }
  }

  // Process a server-rendered custody transfer form.
  async transfer(req, res) {
    try {
      await evidenceService.transferEvidence(req.params.id, {
        ...req.body,
        fromUser: Number(req.body.fromUser),
        toUser: Number(req.body.toUser),
      });
      res.redirect(`/evidence/${req.params.id}`);
    } catch (error) {
      res.status(400).send(error.message);
    }
  }
}

module.exports = new EvidenceViewController();
