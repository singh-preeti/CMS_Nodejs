CREATE TABLE IF NOT EXISTS criminals (
  id SERIAL PRIMARY KEY,
  full_name VARCHAR(200) NOT NULL,
  alias VARCHAR(200),
  date_of_birth DATE,
  crime_type VARCHAR(150) NOT NULL,
  status VARCHAR(50) DEFAULT 'wanted',
  case_id INTEGER,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);