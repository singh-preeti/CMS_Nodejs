const express = require("express");
const criminalViewController = require("../controllers/criminalViewController");

const router = express.Router();
// Redirect the service root to the criminal records page.
router.get("/", (req, res) => res.redirect("/criminals"));
router.get("/criminals", criminalViewController.list);
router.get("/criminals/new", criminalViewController.newForm);
router.post("/criminals/new", criminalViewController.create);
router.get("/criminals/:id", criminalViewController.details);

module.exports = router;
