const criminalService = require("../services/criminalService");

class CriminalController {
  // Return criminal records through the JSON API.
  async list(req, res, next) {
    try {
      res.json(await criminalService.getAllCriminals());
    } catch (error) {
      next(error);
    }
  }

  // Return one criminal record through the JSON API.
  async getById(req, res, next) {
    try {
      res.json(await criminalService.getCriminalById(req.params.id));
    } catch (error) {
      res
        .status(error.message === "Criminal not found" ? 404 : 502)
        .json({ error: error.message });
    }
  }
  // Create a criminal record through the JSON API.
  async create(req, res, next) {
    try {
      res
        .status(201)
        .json(await criminalService.createCriminal(req.body || {}));
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
}

module.exports = new CriminalController();
