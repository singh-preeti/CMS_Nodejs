const amqp = require("amqplib");

const exchangeName = process.env.MESSAGE_EXCHANGE || "evidence.events";
const brokerUrl = process.env.RABBITMQ_URL || "amqp://localhost:5672";

let connection;
let channel;

// Connect to RabbitMQ without preventing the HTTP service from starting if it is unavailable.
async function connectMessageBus(serviceName) {
  try {
    connection = await amqp.connect(brokerUrl);
    channel = await connection.createChannel();
    await channel.assertExchange(exchangeName, "topic", { durable: true });
    console.log(`${serviceName} connected to RabbitMQ at ${brokerUrl}`);
    return channel;
  } catch (error) {
    console.warn(`${serviceName} RabbitMQ unavailable: ${error.message}`);
    return null;
  }
}

// Publish a durable domain event for any interested service.
async function publishEvent(eventName, payload) {
  if (!channel) return false;
  return channel.publish(
    exchangeName,
    eventName,
    Buffer.from(
      JSON.stringify({
        eventName,
        occurredAt: new Date().toISOString(),
        payload,
      }),
    ),
    { persistent: true, contentType: "application/json" },
  );
}

// Subscribe a service to a topic pattern and acknowledge each processed message.
async function subscribeToEvent(serviceName, topicPattern, handler) {
  if (!channel) return;
  const queue = `${serviceName}.${topicPattern.replace(/[^a-zA-Z0-9]/g, "-")}`;
  await channel.assertQueue(queue, { durable: true });
  await channel.bindQueue(queue, exchangeName, topicPattern);
  await channel.consume(queue, async (message) => {
    if (!message) return;
    try {
      await handler(JSON.parse(message.content.toString()));
      channel.ack(message);
    } catch (error) {
      console.error(
        `${serviceName} could not process ${topicPattern}:`,
        error.message,
      );
      channel.nack(message, false, false);
    }
  });
}

module.exports = { connectMessageBus, publishEvent, subscribeToEvent };
