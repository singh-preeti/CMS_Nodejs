const userRepository = require("../repositories/userRepository");
const { publishEvent } = require("../../../shared/messageBus");

class UserService {
  // Load all users through the repository.
  async getAllUsers() {
    return userRepository.getAllUsers();
  }

  // Validate and create a normalized user.
  async createUser({ username, password, role }) {
    if (!username || !username.trim()) throw new Error("Username is required");
    if (!password || !password.trim()) throw new Error("Password is required");
    const user = await userRepository.createUser({
      username: username.trim(),
      password: password.trim(),
      role: role?.trim() || "investigator",
    });
    await publishEvent("user.created", {
      userId: user.id,
      username: user.username,
      role: user.role,
    });
    return user;
  }
}

module.exports = new UserService();
