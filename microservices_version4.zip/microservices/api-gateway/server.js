require("dotenv").config();
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const path = require("path");

const app = express();
const services = {
  users: process.env.USER_SERVICE_URL || "http://localhost:3000",
  cases: process.env.CASE_SERVICE_URL || "http://localhost:3001",
  evidence: process.env.EVIDENCE_SERVICE_URL || "http://localhost:3002",
  criminals: process.env.CRIMINAL_SERVICE_URL || "http://localhost:3003",
};
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 * 1024 },
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// Serve the gateway API explorer.
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Send a request to a backend service and copy its status, content type, and body to the client.
// Keeping this in one function means every gateway route handles upstream responses consistently.
async function proxyResponse(res, url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.text();
  res
    .status(response.status)
    .type(response.headers.get("content-type") || "application/json")
    .send(body);
}

// Build a reusable Express handler for forwarding one gateway route to a backend service.
// For example, proxy("users", () => "/api/users") creates the handler used by GET /api/users.
function proxy(service, endpoint) {
  // Return the actual Express callback after the route has supplied the service and endpoint rules.
  return (req, res, next) =>
    // Build the destination URL, forward the request, and pass network errors to Express error handling.
    proxyResponse(res, `${services[service]}${endpoint(req)}`, {
      method: req.method,
      headers: { "content-type": "application/json" },
      body: ["GET", "HEAD"].includes(req.method)
        ? undefined
        : JSON.stringify(req.body || {}),
    }).catch(next);
}

// Report the availability of every backend service.
app.get("/health", async (req, res) => {
  const checks = await Promise.all(
    // map() runs one health request for every configured service and returns a promise for each request.
    // Promise.all() waits for all of those independent requests before building one combined response.
    Object.entries(services).map(async ([name, url]) => {
      try {
        const response = await fetch(`${url}/health`);
        // Return a [key, value] pair so Object.fromEntries() can create { users: "up", ... }.
        return [name, response.ok ? "up" : "down"];
      } catch {
        // A connection failure marks only this service as down; other health checks can still succeed.
        return [name, "down"];
      }
    }),
  );
  res.json({
    service: "api-gateway",
    status: "running",
    port: 4000,
    services: Object.fromEntries(checks),
  });
});

app.get(
  "/api/users",
  proxy("users", () => "/api/users"),
);
app.post(
  "/api/users",
  proxy("users", () => "/api/users"),
);

app.get(
  "/api/cases",
  proxy("cases", () => "/api/cases"),
);
app.get(
  "/api/cases/:id",
  proxy("cases", (req) => `/api/cases/${req.params.id}`),
);
app.post(
  "/api/cases",
  proxy("cases", () => "/api/cases"),
);

app.get(
  "/api/evidence",
  proxy(
    "evidence",
    (req) =>
      `/api/evidence${req.query.caseId ? `?caseId=${encodeURIComponent(req.query.caseId)}` : ""}`,
  ),
);
app.get(
  "/api/evidence/:id",
  proxy("evidence", (req) => `/api/evidence/${req.params.id}`),
);
app.get(
  "/api/evidence/:id/custody",
  proxy("evidence", (req) => `/api/evidence/${req.params.id}/custody`),
);
app.post(
  "/api/evidence/:id/transfer",
  proxy("evidence", (req) => `/api/evidence/${req.params.id}/transfer`),
);
app.post(
  "/api/evidence/:id/verify",
  proxy("evidence", (req) => `/api/evidence/${req.params.id}/verify`),
);
// Forward a multipart evidence upload to the Evidence service.
app.post(
  "/api/evidence/upload",
  upload.single("file"),
  async (req, res, next) => {
    try {
      const form = new FormData();
      if (req.file)
        form.append("file", new Blob([req.file.buffer]), req.file.originalname);
      for (const [key, value] of Object.entries(req.body || {}))
        form.append(key, value);
      await proxyResponse(res, `${services.evidence}/api/evidence/upload`, {
        method: "POST",
        body: form,
      });
    } catch (error) {
      next(error);
    }
  },
);

app.get(
  "/api/criminals",
  proxy("criminals", () => "/api/criminals"),
);
app.get(
  "/api/criminals/:id",
  proxy("criminals", (req) => `/api/criminals/${req.params.id}`),
);
app.post(
  "/api/criminals",
  proxy("criminals", () => "/api/criminals"),
);

// Convert upstream communication failures into gateway errors.
app.use((error, req, res, next) => {
  console.error(error);
  res
    .status(502)
    .json({ error: "API gateway could not reach the requested service" });
});

// Start the gateway on its configured port.
const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`API gateway listening on ${port}`));
