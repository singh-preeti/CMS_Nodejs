# Postman Requests for the Microservices App

Base URL used for the gateway:

```http
http://localhost:4000
```

Use these requests in Postman to create users, cases, evidence, and criminals.

---

## 1) Create User

Method: POST
URL: http://localhost:4000/api/users

Headers:
```http
Content-Type: application/json
```

Body (raw JSON):
```json
{
  "username": "investigator01",
  "password": "secret123",
  "role": "investigator"
}
```

If username already exists, you will get:
```json
{
  "error": "Username already exists"
}
```

---

## 2) Get All Users

Method: GET
URL: http://localhost:4000/api/users

---

## 3) Create Case

Method: POST
URL: http://localhost:4000/api/cases

Headers:
```http
Content-Type: application/json
```

Body (raw JSON):
```json
{
  "title": "Fraud investigation",
  "investigatorId": 1,
  "caseNumber": "CASE-1001"
}
```

Optional shorter version:
```json
{
  "title": "Fraud investigation"
}
```

If `caseNumber` is missing, the system creates one automatically.

---

## 4) Get All Cases

Method: GET
URL: http://localhost:4000/api/cases

---

## 5) Upload Evidence

Method: POST
URL: http://localhost:4000/api/evidence/upload

Body type: form-data

Copy this exactly in Postman:

```text
Key: file
Value: choose any file from your computer

Key: caseId
Value: 1

Key: type
Value: invoice

Key: uploadedBy
Value: 1
```

Example in Postman form-data:
```text
file: sample.pdf
caseId: 1
type: invoice
uploadedBy: 1
```

Important: this is multipart form-data, not raw JSON.

---

## 6) Get All Evidence

Method: GET
URL: http://localhost:4000/api/evidence

Optional filter by case:
```http
http://localhost:4000/api/evidence?caseId=1
```

---

## 7) Create Criminal Record

Method: POST
URL: http://localhost:4000/api/criminals

Headers:
```http
Content-Type: application/json
```

Body (raw JSON):
```json
{
  "fullName": "John Smith",
  "alias": "The Broker",
  "dateOfBirth": "1990-05-15",
  "crimeType": "Fraud",
  "status": "wanted",
  "caseId": 1,
  "createdBy": 1
}
```

---

## 8) Get All Criminals

Method: GET
URL: http://localhost:4000/api/criminals

---

## Beginner-Friendly Example Flow

1. Create user
```json
{
  "username": "investigator01",
  "password": "secret123",
  "role": "investigator"
}
```

2. Create case
```json
{
  "title": "Fraud investigation",
  "investigatorId": 1,
  "caseNumber": "CASE-1001"
}
```

3. Upload evidence using form-data
```text
file = yourfile.pdf
caseId = 1
type = invoice
uploadedBy = 1
```

4. Create criminal
```json
{
  "fullName": "John Smith",
  "crimeType": "Fraud",
  "caseId": 1,
  "createdBy": 1
}
```

---

## Quick Notes

- Use unique usernames to avoid 409 conflict.
- Always use valid IDs from existing records in the database.
- For evidence, use form-data, not JSON.
- The gateway URL is http://localhost:4000, which forwards requests to the individual services.
