const express = require("express");
const caseViewController = require("../controllers/caseViewController");

const router = express.Router();
// Redirect the service root to the cases page.
router.get("/", (req, res) => res.redirect("/cases"));
// Render and submit case pages.
router.get("/cases", caseViewController.list);
router.post("/cases", caseViewController.create);
router.get("/cases/:id", caseViewController.details);

module.exports = router;
