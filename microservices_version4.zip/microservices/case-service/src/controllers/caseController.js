const caseService = require("../services/caseService");

class CaseController {
  // Return all cases through the JSON API.
  async getAllCases(req, res, next) {
    try {
      res.json(await caseService.getAllCases());
    } catch (error) {
      next(error);
    }
  }

  // Return one case and its related service data.
  async getCaseById(req, res, next) {
    try {
      res.json(await caseService.getCaseById(req.params.id));
    } catch (error) {
      res
        .status(error.message === "Case not found" ? 404 : 502)
        .json({ error: error.message });
    }
  }

  // Create a case through the Case service.
  async createCase(req, res) {
    try {
      res.status(201).json(await caseService.createCase(req.body || {}));
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
}

module.exports = new CaseController();
