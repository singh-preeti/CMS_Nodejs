const caseService = require("../services/caseService");
const userServiceUrl = process.env.USER_SERVICE_URL || "http://localhost:3000";

// Load users for the investigator selection list.
async function getUsers() {
  const response = await fetch(`${userServiceUrl}/api/users`);
  return response.json();
}

class CaseViewController {
  // Render the cases page with users from User service.
  async list(req, res) {
    try {
      res.render("cases", {
        title: "Cases",
        page: "cases",
        cases: await caseService.getAllCases(),
        users: await getUsers(),
        error: null,
        values: {},
      });
    } catch (error) {
      res.status(502).send(error.message);
    }
  }

  // Process the create-case form.
  async create(req, res) {
    try {
      await caseService.createCase({
        ...req.body,
        investigatorId: Number(req.body.investigatorId) || null,
      });
      res.redirect("/cases");
    } catch (error) {
      res
        .status(400)
        .render("cases", {
          title: "Cases",
          page: "cases",
          cases: await caseService.getAllCases(),
          users: await getUsers(),
          error: error.message,
          values: req.body || {},
        });
    }
  }

  // Render one case with evidence from Evidence service.
  async details(req, res) {
    try {
      const caseData = await caseService.getCaseById(req.params.id);
      res.render("case-details", {
        title: caseData.case_number,
        page: "cases",
        caseData,
      });
    } catch (error) {
      res.status(404).send(error.message);
    }
  }
}

module.exports = new CaseViewController();
