const pool = require("../config/database");

class CaseRepository {
  // Return all cases ordered by creation time.
  async getAllCases() {
    return (await pool.query("SELECT * FROM cases ORDER BY created_at DESC"))
      .rows;
  }

  // Return one case or null when it does not exist.
  async getCaseById(caseId) {
    return (
      (await pool.query("SELECT * FROM cases WHERE id = $1", [caseId]))
        .rows[0] || null
    );
  }

  // Persist a new case record.
  async createCase({ caseNumber, title, investigatorId }) {
    return (
      await pool.query(
        "INSERT INTO cases (case_number, title, investigator_id) VALUES ($1, $2, $3) RETURNING *",
        [caseNumber, title, investigatorId],
      )
    ).rows[0];
  }
}

module.exports = new CaseRepository();
