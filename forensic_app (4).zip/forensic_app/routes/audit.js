const express = require("express");
const { pool } = require("../database/database");
const requireLogin = require("../middleware/auth");

const router = express.Router();

router.get("/", requireLogin, async (req, res, next) => {
  try {
    const { rows: auditLogs } = await pool.query(`
      SELECT audit_log.*, users.username
      FROM audit_log
      LEFT JOIN users ON users.user_id = audit_log.user_id
      ORDER BY audit_log.timestamp DESC
    `);
    res.render("audit-log", { user: req.session.user, auditLogs });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
