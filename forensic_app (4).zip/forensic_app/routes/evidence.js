const express = require("express");
const { body, validationResult } = require("express-validator");
const { pool, recordAudit } = require("../database/database");
const requireLogin = require("../middleware/auth");

const router = express.Router();

const evidenceValidation = [
  body("case_id").trim().notEmpty().withMessage("Case ID is required."),
  body("type").trim().notEmpty().withMessage("Evidence type is required."),
  body("file_path").trim().notEmpty().withMessage("File path is required."),
  body("hash").trim().notEmpty().withMessage("Evidence hash is required."),
];

// Load the cases available in the evidence form.
async function getCases() {
  const { rows } = await pool.query(
    "SELECT case_id, name FROM cases ORDER BY created_date DESC"
  );

  return rows;
}

// Show filtered evidence with status counts and pagination.
router.get("/dashboard", requireLogin, async (req, res, next) => {
  try {
    const {
      type = "",
      status = "",
      from = "",
      to = "",
      page = "1",
    } = req.query;
    const pageNumber = Math.max(Number.parseInt(page, 10) || 1, 1);
    const limit = 10;
    const values = [];
    const filters = [];

    if (type) {
      values.push(type);
      filters.push(`e.type = $${values.length}`);
    }

    if (status) {
      values.push(status);
      filters.push(`e.status = $${values.length}`);
    }

    if (from) {
      values.push(from);
      filters.push(`e.upload_date >= $${values.length}`);
    }

    if (to) {
      values.push(`${to} 23:59:59`);
      filters.push(`e.upload_date <= $${values.length}`);
    }

    const whereClause = filters.length > 0
      ? `WHERE ${filters.join(" AND ")}`
      : "";
    const countResult = await pool.query(
      `SELECT COUNT(*)::int AS total FROM evidence e ${whereClause}`,
      values
    );

    values.push(limit, (pageNumber - 1) * limit);
    const { rows: evidence } = await pool.query(`
      SELECT
        e.evidence_id,
        e.case_id,
        e.type,
        e.file_path,
        e.hash,
        e.upload_date,
        e.status,
        c.name AS case_name
      FROM evidence e
      JOIN cases c ON c.case_id = e.case_id
      ${whereClause}
      ORDER BY e.upload_date DESC
      LIMIT $${values.length - 1}
      OFFSET $${values.length}
    `, values);

    const { rows: statusCounts } = await pool.query(
      "SELECT status, COUNT(*)::int AS total FROM evidence GROUP BY status ORDER BY status"
    );

    res.render("dashboard", {
      user: req.session.user,
      evidence,
      statusCounts,
      filters: { type, status, from, to },
      page: pageNumber,
      pages: Math.max(Math.ceil(countResult.rows[0].total / limit), 1),
    });
  } catch (error) {
    next(error);
  }
});

// Display the form for registering evidence.
router.get("/new", requireLogin, async (req, res, next) => {
  try {
    res.render("evidence-form", {
      user: req.session.user,
      error: null,
      values: {},
      cases: await getCases(),
    });
  } catch (error) {
    next(error);
  }
});

// Register evidence, its first custody record, and its audit record.
router.post("/new", requireLogin, evidenceValidation, async (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).render("evidence-form", {
      user: req.session.user,
      error: errors.array()[0].msg,
      values: req.body,
      cases: await getCases(),
    });
  }

  const { case_id, type, file_path, hash } = req.body;
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const result = await client.query(
      `INSERT INTO evidence (case_id, type, file_path, hash, status)
       VALUES ($1, $2, $3, $4, 'Pending')
       RETURNING evidence_id`,
      [case_id.trim(), type.trim(), file_path.trim(), hash.trim()]
    );
    const evidenceId = result.rows[0].evidence_id;

    await client.query(
      `INSERT INTO custody
       (evidence_id, action, from_officer, to_officer)
       VALUES ($1, $2, $3, $4)`,
      [evidenceId, "Evidence Registered", null, req.session.user.username]
    );

    await client.query(
      `INSERT INTO audit_log
       (user_id, action, entity_type, entity_id)
       VALUES ($1, $2, $3, $4)`,
      [req.session.user.id, "Evidence Created", "evidence", evidenceId]
    );

    await client.query("COMMIT");
    res.redirect("/evidence/dashboard");
  } catch (error) {
    await client.query("ROLLBACK");

    if (error.code === "23503") {
      return res.status(400).render("evidence-form", {
        user: req.session.user,
        error: "The selected case does not exist.",
        values: req.body,
        cases: await getCases(),
      });
    }

    next(error);
  } finally {
    client.release();
  }
});

// Show evidence details together with its custody history.
router.get("/:id", requireLogin, async (req, res, next) => {
  try {
    const { rows: evidenceRows } = await pool.query(`
      SELECT e.*, c.name AS case_name
      FROM evidence e
      JOIN cases c ON c.case_id = e.case_id
      WHERE e.evidence_id = $1
    `, [req.params.id]);

    if (!evidenceRows[0]) {
      return res.status(404).send("Evidence not found");
    }

    const { rows: custody } = await pool.query(
      "SELECT * FROM custody WHERE evidence_id = $1 ORDER BY timestamp ASC",
      [req.params.id]
    );

    res.render("evidence-details", {
      evidence: evidenceRows[0],
      custody,
      user: req.session.user,
    });
  } catch (error) {
    next(error);
  }
});

// Update evidence status and append a custody and audit record.
router.post("/:id/status", requireLogin, async (req, res, next) => {
  const { status, to_officer, notes } = req.body;

  if (!status || !status.trim()) {
    return res.status(400).send("Status is required");
  }

  try {
    const { rows } = await pool.query(
      "SELECT * FROM evidence WHERE evidence_id = $1",
      [req.params.id]
    );

    if (!rows[0]) {
      return res.status(404).send("Evidence not found");
    }

    await pool.query(
      "UPDATE evidence SET status = $1 WHERE evidence_id = $2",
      [status.trim(), req.params.id]
    );

    await pool.query(
      `INSERT INTO custody
       (evidence_id, action, from_officer, to_officer)
       VALUES ($1, $2, $3, $4)`,
      [
        req.params.id,
        notes ? notes.trim() : `Status changed to ${status.trim()}`,
        req.session.user.username,
        to_officer ? to_officer.trim() : req.session.user.username,
      ]
    );

    await recordAudit(
      req.session.user.id,
      "Evidence Status Updated",
      "evidence",
      req.params.id
    );

    res.redirect(`/evidence/${req.params.id}`);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
