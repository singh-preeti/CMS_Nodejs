const express = require("express");
const { body, validationResult } = require("express-validator");
const { pool, recordAudit } = require("../database/database");
const requireLogin = require("../middleware/auth");

const router = express.Router();
const caseValidation = [
  body("case_id").trim().notEmpty().withMessage("Case ID is required."),
  body("name").trim().notEmpty().withMessage("Case name is required."),
  body("status").trim().notEmpty().withMessage("Case status is required."),
  body("assigned_investigator").isInt().withMessage("Investigator is required."),
];

async function renderForm(res, user, error = null, values = {}) {
  const { rows: investigators } = await pool.query(
    "SELECT user_id, username, department FROM users ORDER BY username"
  );
  res.status(error ? 400 : 200).render("case-form", { user, error, values, investigators });
}

router.get("/", requireLogin, async (req, res, next) => {
  try {
    const investigator = req.query.investigator;
    const params = investigator ? [investigator] : [];
    const { rows: cases } = await pool.query(`
      SELECT c.case_id, c.name, c.status, c.created_date,
             u.username AS investigator, COUNT(e.evidence_id)::int AS evidence_count
      FROM cases c
      LEFT JOIN users u ON u.user_id = c.assigned_investigator
      LEFT JOIN evidence e ON e.case_id = c.case_id
      ${investigator ? "WHERE c.assigned_investigator = $1" : ""}
      GROUP BY c.case_id, c.name, c.status, c.created_date, u.username
      ORDER BY c.created_date DESC
    `, params);
    res.render("cases", { user: req.session.user, cases, selectedInvestigator: investigator || "" });
  } catch (error) { next(error); }
});

router.get("/new", requireLogin, (req, res, next) => {
  renderForm(res, req.session.user).catch(next);
});

router.post("/new", requireLogin, caseValidation, async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return renderForm(res, req.session.user, errors.array()[0].msg, req.body);

  const { case_id, name, status, assigned_investigator } = req.body;
  try {
    await pool.query(
      "INSERT INTO cases (case_id, name, status, assigned_investigator) VALUES ($1, $2, $3, $4)",
      [case_id.trim(), name.trim(), status.trim(), Number(assigned_investigator)]
    );
    await recordAudit(req.session.user.id, "Case Created", "case", case_id.trim());
    res.redirect("/cases");
  } catch (error) {
    if (error.code === "23505") return renderForm(res, req.session.user, "Case ID already exists.", req.body);
    next(error);
  }
});

module.exports = router;
