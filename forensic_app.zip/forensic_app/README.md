# Secure Evidence Management System

This project is a forensic evidence tracking application built with Node.js, Express.js, EJS, and PostgreSQL. It demonstrates how to build a secure server-side rendered application for managing evidence records and maintaining a basic chain of custody.

---

## 1. Project Goal

The app allows an investigator to:

- log in securely
- view the dashboard
- add a new evidence item
- open evidence details
- update the status of evidence
- record chain-of-custody activity
- protect routes using sessions
- validate data before saving it

---

## 2. Tech Stack

- Node.js
- Express.js
- EJS (server-side rendering)
- PostgreSQL database
- `pg` PostgreSQL client
- express-session
- bcrypt
- express-validator
- helmet
- nodemon (development only)

---

## 3. Application Flow

The general workflow is:

```text
Browser
  ↓
Express app
  ↓
Routes and middleware
  ↓
PostgreSQL database
  ↓
EJS templates
  ↓
HTML rendered to browser
```

This is a server-side rendering application, meaning the HTML is generated on the server before it reaches the browser.

---

## 4. Project Structure

```text
forensic_app/
├── app.js
├── package.json
├── README.md
├── create-user.js
├── .gitignore
├── database/
│   └── database.js
├── middleware/
│   └── auth.js
├── public/
│   └── css/
│       └── style.css
├── routes/
│   ├── auth.js
│   └── evidence.js
├── views/
│   ├── dashboard.ejs
│   ├── evidence-details.ejs
│   ├── evidence-form.ejs
│   ├── login.ejs
│   └── partials/
│       ├── header.ejs
│       └── footer.ejs
└── node_modules/
```

---

## 5. Step-by-Step Development Process

### Step 1: Initialize the project

The project was started with:

```bash
npm init -y
```

This created the base `package.json` file.

### Step 2: Install dependencies

These packages are required:

```bash
npm install express ejs express-session bcrypt helmet express-validator pg
npm install --save-dev nodemon
```


Think of our Evidence Management application as a real office:

                Evidence Management Application
                           │
        ┌──────────────────┼──────────────────┐
        ↓                  ↓                  ↓
    Express             EJS           PostgreSQL
     Server            Frontend            Database
        │
        ├── Session → Login
        ├── bcrypt → Password Security
        ├── Helmet → HTTP Security
        └── Validator → Input Validation

This gave the app the tools required for:

- web server
- HTML rendering
- session management
- password security
- security headers
- validation
- PostgreSQL database access

### Step 3: Configure `package.json`

The scripts were set up so the app can run in both normal and development mode:

```json
"scripts": {
  "start": "node app.js",
  "dev": "nodemon app.js"
}
```

### Step 4: Create the main server in `app.js`

The main app file does the following:

- creates the Express app
- applies Helmet for security headers
- parses form data from POST requests
- serves static CSS files
- sets EJS as the view engine
- sets up session handling
- mounts the authentication and evidence routes
- redirects users to login when unauthenticated

Example:

```js
app.use(helmet());
app.use(express.urlencoded({ extended: true }));
app.set("view engine", "ejs");
app.use(session({ ... }));
```

### Step 5: Create a PostgreSQL database setup

The database is initialized in `database/database.js`. Configure the connection with either a `DATABASE_URL` connection string or the standard PostgreSQL environment variables (`PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, and `PGPASSWORD`).

Example PowerShell setup:

```powershell
$env:DATABASE_URL = "postgresql://username:password@localhost:5432/evidence_management"
npm start
```

It creates three tables:

- `users`
- `evidence`
- `custody`

The `users` table stores login credentials.
The `evidence` table stores the evidence records.
The `custody` table stores the chain-of-custody history.

The database also creates a default investigator account on first run:

```text
Username: investigator
Password: admin123
```

### Step 6: Create authentication middleware

The middleware in `middleware/auth.js` guards routes like the dashboard and evidence management pages.

```js
function requireLogin(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.redirect("/login");
  }
  next();
}
```

This ensures only logged-in users can access protected pages.

### Step 7: Create login logic

The login route in `routes/auth.js` does the following:

- receives username and password
- looks up the user in PostgreSQL
- verifies the hash using `bcrypt.compare()`
- stores the user in the session
- redirects to the dashboard on success

### Step 8: Create the dashboard and evidence routes

The `routes/evidence.js` file manages:

- dashboard display
- adding evidence
- viewing a single record
- updating evidence status
- recording custody history

Validation is done with `express-validator` before saving entries.

### Step 9: Create EJS pages

The front end is rendered server-side using EJS files in `views/`.

The templates include:

- login page
- dashboard
- evidence registration form
- evidence details page

Each page uses variables passed from the routes, such as:

```js
res.render("dashboard", {
  user: req.session.user,
  evidence,
});
```

### Step 10: Add CSS styling

The styling is in `public/css/style.css`. It gives the app a simple, clean forensic dashboard style.

### Step 11: Add chain-of-custody tracking

When evidence is registered or status changes, the app inserts records into the `custody` table.

This tracks actions such as:

- Evidence Collected
- Status Updated: Transferred to Lab
- Status Updated: Examined
- Status Updated: Stored

This creates the evidence history for investigation and accountability.

---

## 6. Security Features Included

The app includes several basic security measures:

- bcrypt password hashing
- HTTP security headers with Helmet
- session-based authentication
- route protection through middleware
- parameterized SQL queries using PostgreSQL placeholders
- form validation to reduce malicious or malformed input

---

## 7. Example Evidence Workflow

The project supports this lifecycle:

```text
Collected
  ↓
Transferred to Lab
  ↓
Examined
  ↓
Stored
```

Each transition is recorded in the chain-of-custody log.

---

## 8. How to Run the Project

### Install dependencies

```bash
npm install
```

### Start the app

```bash
npm start
```

### Run in development mode

```bash
npm run dev
```

### Open the app

```text
http://localhost:3000
```

---

## 9. Default Credentials

```text
Username: investigator
Password: admin123
```

---

## 10. Security Notes for Production

This is a learning project and uses a default development session secret. For production, you should:

- use environment variables
- store secrets in `.env`
- enable HTTPS
- add CSRF protection
- add rate limiting
- add role-based authorization
- use a stronger production database setup

Example:

```bash
SESSION_SECRET=your-very-long-random-secret
```

---

## 11. Summary

This project demonstrates a complete beginner-friendly Node.js web application that includes:

- authentication
- session management
- EJS rendering
- database integration
- evidence tracking
- chain-of-custody practice
- secure backend fundamentals

It is a strong base for a real forensic evidence management system.
