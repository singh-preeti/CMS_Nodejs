const bcrypt = require("bcrypt");
const { pool, initializeDatabase } = require("./database/database");

async function createUser() {
  const username = "investigator";
  const password = "admin123";
  const hashedPassword = await bcrypt.hash(password, 12);

  try {
    await initializeDatabase();
    await pool.query(`INSERT INTO users (username, password) VALUES ($1, $2)`, [
      username,
      hashedPassword
    ]);
    console.log("User created successfully");
  } catch (error) {
    console.log("User may already exist.");
  } finally {
    await pool.end();
  }
}

createUser();
