const express = require("express");
const path = require("path");
const session = require("express-session");
const helmet = require("helmet");

const authRoutes = require("./routes/auth");
const evidenceRoutes = require("./routes/evidence");
const { initializeDatabase } = require("./database/database");

const app = express();

app.use(helmet({
  contentSecurityPolicy: false,
}));

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(
  session({
    secret: process.env.SESSION_SECRET || "change-this-secret-in-production",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      maxAge: 30 * 60 * 1000,
      secure: false,
    },
  })
);

app.use("/", authRoutes);
app.use("/evidence", evidenceRoutes);

app.get("/", (req, res) => {
  if (req.session.user) {
    return res.redirect("/evidence/dashboard");
  }

  res.redirect("/login");
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send("Something went wrong!");
});

const PORT = process.env.PORT || 3000;

initializeDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Evidence Management System running at http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error("Unable to initialize PostgreSQL database", error);
    process.exit(1);
  });
