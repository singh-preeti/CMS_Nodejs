const { Pool } = require("pg");
const bcrypt = require("bcrypt");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

async function initializeDatabase() {
  await pool.query(`
  CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
  )
`);

  await pool.query(`
  CREATE TABLE IF NOT EXISTS evidence (
    id SERIAL PRIMARY KEY,
    evidence_code VARCHAR(255) UNIQUE NOT NULL,
    case_id VARCHAR(255) NOT NULL,
    type VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    collected_by VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
`);

  await pool.query(`
  CREATE TABLE IF NOT EXISTS custody (
    id SERIAL PRIMARY KEY,
    evidence_id INTEGER NOT NULL REFERENCES evidence(id),
    action VARCHAR(255) NOT NULL,
    performed_by VARCHAR(255) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
`);

  const { rows } = await pool.query("SELECT COUNT(*) AS total FROM users");

  if (Number(rows[0].total) === 0) {
    const passwordHash = await bcrypt.hash("admin123", 12);
    await pool.query(
      "INSERT INTO users (username, password) VALUES ($1, $2)",
      ["investigator", passwordHash]
    );

    console.log("Default investigator user created: investigator / admin123");
  }
}

module.exports = { pool, initializeDatabase };
